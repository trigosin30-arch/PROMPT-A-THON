"""NODEX — Enterprise Distributed Object Storage Engine.
Nodes are per-account folders on one machine (simulated cluster).
Roles: user / admin / superadmin
"""
import asyncio
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import sqlite3
import threading
import time
import uuid
from collections import defaultdict, deque
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, File, HTTPException, Query, Request, Response, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

# ─── Paths & Config ───────────────────────────────────────────────────────────
BASE = Path(__file__).resolve().parent.parent
DATA = Path(os.environ.get("NODEX_DATA_DIR") or os.environ.get("SAD_DATA_DIR") or os.environ.get("AUREVIA_DATA_DIR") or str(BASE / "data"))
STORAGE = Path(os.environ.get("NODEX_STORAGE_DIR") or os.environ.get("SAD_STORAGE_DIR") or os.environ.get("AUREVIA_STORAGE_DIR") or str(BASE / "storage"))
DATA.mkdir(parents=True, exist_ok=True)
STORAGE.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA / ("storageatdell.db" if (DATA / "storageatdell.db").exists() else "nodex.db")
SESSION_COOKIE = "nodex_session"
SESSION_SECONDS = 60 * 60 * 24 * 30
MAX_UPLOAD = 100 * 1024 * 1024
USER_QUOTA = 1024 * 1024 * 1024  # 1 GB per user
NODE_NAMES = ["node1", "node2", "node3", "node4"]
NODE_LABELS = {n: f"Storage Node {i:02}" for i, n in enumerate(NODE_NAMES, 1)}
NODE_CAPACITY = 10 * 1024 * 1024 * 1024  # 10 GB per node (simulated)
GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")
lock = threading.RLock()
attempts: dict = defaultdict(deque)

# In-memory metric store
_metrics_lock = threading.Lock()
_latency_log: deque = deque(maxlen=500)   # (ts, ms)
_throughput_log: deque = deque(maxlen=500) # (ts, bytes)
_repair_log: deque = deque(maxlen=100)     # (ts, duration_ms, count)

def record_latency(ms: float):
    with _metrics_lock:
        _latency_log.append((time.time(), ms))

def record_throughput(nbytes: int):
    with _metrics_lock:
        _throughput_log.append((time.time(), nbytes))


# ─── DB ───────────────────────────────────────────────────────────────────────
@contextmanager
def db():
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()

def now_ts():
    return datetime.now(timezone.utc).isoformat()

def init_db():
    with db() as con:
        con.executescript('''
        CREATE TABLE IF NOT EXISTS users(
            user_id TEXT PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT,
            google_sub TEXT UNIQUE,
            role TEXT NOT NULL DEFAULT 'user',
            created_at TEXT NOT NULL,
            is_suspended INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS sessions(
            token_hash TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at REAL
        );
        CREATE TABLE IF NOT EXISTS objects(
            object_id TEXT PRIMARY KEY,
            filename TEXT NOT NULL,
            size INTEGER NOT NULL,
            content_type TEXT NOT NULL,
            sha256 TEXT NOT NULL,
            replication INTEGER NOT NULL,
            version INTEGER NOT NULL DEFAULT 1,
            tags TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            user_id TEXT
        );
        CREATE TABLE IF NOT EXISTS replicas(
            object_id TEXT NOT NULL,
            node TEXT NOT NULL,
            status TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY(object_id, node)
        );
        CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            message TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'info',
            created_at TEXT NOT NULL,
            user_id TEXT
        );
        CREATE TABLE IF NOT EXISTS user_nodes(
            user_id TEXT NOT NULL,
            node TEXT NOT NULL,
            status TEXT NOT NULL,
            PRIMARY KEY(user_id, node)
        );
        CREATE TABLE IF NOT EXISTS policies(
            user_id TEXT PRIMARY KEY,
            replication_factor INTEGER NOT NULL DEFAULT 3,
            read_quorum INTEGER NOT NULL DEFAULT 1,
            write_quorum INTEGER NOT NULL DEFAULT 2,
            max_upload_bytes INTEGER NOT NULL DEFAULT 104857600,
            quota_bytes INTEGER NOT NULL DEFAULT 1073741824,
            auto_repair INTEGER NOT NULL DEFAULT 1,
            versioning INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS write_locks(
            object_id TEXT PRIMARY KEY,
            locked_by TEXT NOT NULL,
            locked_at REAL NOT NULL
        );
        ''')
        # Migrations
        for table, column, kind, default in [
            ("objects", "user_id", "TEXT", None),
            ("objects", "version", "INTEGER", "1"),
            ("objects", "tags", "TEXT", "'{}'"),
            ("objects", "updated_at", "TEXT", "''"),
            ("events", "user_id", "TEXT", None),
            ("events", "severity", "TEXT", "'info'"),
            ("sessions", "expires_at", "REAL", None),
            ("users", "role", "TEXT", "'user'"),
            ("users", "is_suspended", "INTEGER", "0"),
        ]:
            cols = {r["name"] for r in con.execute(f"PRAGMA table_info({table})")}
            if column not in cols:
                if default:
                    con.execute(f"ALTER TABLE {table} ADD COLUMN {column} {kind} DEFAULT {default}")
                else:
                    con.execute(f"ALTER TABLE {table} ADD COLUMN {column} {kind}")
        con.execute("CREATE INDEX IF NOT EXISTS objects_owner ON objects(user_id, created_at)")
        con.execute("CREATE INDEX IF NOT EXISTS events_owner ON events(user_id, id)")
        con.execute("DELETE FROM sessions WHERE expires_at IS NULL OR expires_at < ?", (time.time(),))
        con.execute("DELETE FROM write_locks WHERE locked_at < ?", (time.time() - 300,))

init_db()

secret_path = DATA / ".session-secret"
if not secret_path.exists():
    try:
        with secret_path.open("x", encoding="ascii") as h:
            h.write(secrets.token_hex(32))
    except FileExistsError:
        pass
SESSION_SECRET = os.environ.get("SAD_SESSION_SECRET") or secret_path.read_text(encoding="ascii").strip()


# ─── Helpers ──────────────────────────────────────────────────────────────────
def sha256_file(path: Path) -> str:
    with path.open("rb") as h:
        return hashlib.file_digest(h, "sha256").hexdigest()

def path_for(object_id: str, node: str) -> Path:
    if not re.fullmatch(r"[a-f0-9]{32}", object_id) or node not in NODE_NAMES:
        raise HTTPException(404, "Object or node not found")
    return STORAGE / node / object_id

def public_user(row) -> dict:
    return {"user_id": row["user_id"], "email": row["email"], "role": row["role"]}

def password_hash(password: str, salt: Optional[bytes] = None) -> str:
    salt = salt or secrets.token_bytes(16)
    return base64.b64encode(salt + hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 240_000)).decode()

def verify_password(password: str, stored: str) -> bool:
    try:
        raw = base64.b64decode(stored)
        return hmac.compare_digest(password_hash(password, raw[:16]), stored)
    except (ValueError, TypeError):
        return False

def token_hash(token: str) -> str:
    return hashlib.sha256((SESSION_SECRET + token).encode()).hexdigest()

def current_user(request: Request):
    token = request.cookies.get(SESSION_COOKIE, "")
    with db() as con:
        row = con.execute(
            "SELECT u.* FROM sessions s JOIN users u ON u.user_id=s.user_id "
            "WHERE token_hash=? AND expires_at>? AND u.is_suspended=0",
            (token_hash(token), time.time())
        ).fetchone()
    if not row:
        raise HTTPException(401, "Please sign in again. Your session may have expired.")
    return row

def require_admin(request: Request):
    u = current_user(request)
    if u["role"] not in ("admin", "superadmin"):
        raise HTTPException(403, "Admin access required")
    return u

def require_superadmin(request: Request):
    u = current_user(request)
    if u["role"] != "superadmin":
        raise HTTPException(403, "Superadmin access required")
    return u

def new_session(user, response: Response) -> dict:
    token = secrets.token_urlsafe(32)
    with db() as con:
        con.execute("DELETE FROM sessions WHERE expires_at < ?", (time.time(),))
        con.execute("INSERT INTO sessions VALUES(?,?,?,?)",
                    (token_hash(token), user["user_id"], now_ts(), time.time() + SESSION_SECONDS))
    response.set_cookie(SESSION_COOKIE, token, httponly=True, samesite="strict", max_age=SESSION_SECONDS)
    return {"success": True, "user": public_user(user)}

def rate_limit(request: Request):
    key = request.client.host if request.client else "local"
    with lock:
        bucket = attempts[key]
        stamp = time.monotonic()
        while bucket and bucket[0] < stamp - 60:
            bucket.popleft()
        if len(bucket) >= 15:
            raise HTTPException(429, "Too many attempts. Wait one minute.")
        bucket.append(stamp)

def event(user_id: str, kind: str, message: str, severity: str = "info"):
    with db() as con:
        con.execute("INSERT INTO events(event_type,message,severity,created_at,user_id) VALUES(?,?,?,?,?)",
                    (kind, message, severity, now_ts(), user_id))

def get_policy(user_id: str) -> dict:
    with db() as con:
        row = con.execute("SELECT * FROM policies WHERE user_id=?", (user_id,)).fetchone()
    if row:
        return dict(row)
    return {"user_id": user_id, "replication_factor": 3, "read_quorum": 1, "write_quorum": 2,
            "max_upload_bytes": MAX_UPLOAD, "quota_bytes": USER_QUOTA, "auto_repair": 1, "versioning": 0}

def statuses(user_id: str) -> dict:
    with db() as con:
        rows = con.execute("SELECT node,status FROM user_nodes WHERE user_id=?", (user_id,)).fetchall()
    return {**dict.fromkeys(NODE_NAMES, "healthy"), **{r["node"]: r["status"] for r in rows}}

def owned_objects(user_id: str):
    with db() as con:
        return con.execute("SELECT * FROM objects WHERE user_id=? ORDER BY created_at DESC", (user_id,)).fetchall()

def owned_object(object_id: str, user_id: str):
    with db() as con:
        row = con.execute("SELECT * FROM objects WHERE object_id=? AND user_id=?", (object_id, user_id)).fetchone()
    if not row:
        raise HTTPException(404, "Object not found")
    return row

def valid_nodes(obj, states: dict) -> list:
    valid = []
    for node in NODE_NAMES:
        try:
            p = path_for(obj["object_id"], node)
            if states[node] == "healthy" and p.is_file() and sha256_file(p) == obj["sha256"]:
                valid.append(node)
        except OSError:
            pass
    return valid

def describe(obj, states: dict) -> dict:
    valid = valid_nodes(obj, states)
    replicas = []
    for n in NODE_NAMES:
        p = path_for(obj["object_id"], n)
        exists = p.is_file()
        if states[n] != "healthy":
            st = "failed"
        elif n in valid:
            st = "healthy"
        elif exists:
            st = "corrupted"
        else:
            st = "unused"
        size_on_disk = p.stat().st_size if exists else 0
        replicas.append({"node": n, "label": NODE_LABELS[n], "exists": exists, "status": st, "size": size_on_disk})
    tags = {}
    try:
        tags = json.loads(obj["tags"] or "{}")
    except Exception:
        pass
    return {
        **dict(obj),
        "tags": tags,
        "verified_nodes": valid,
        "verified_replicas": len(valid),
        "healthy": len(valid) >= obj["replication"],
        "integrity": bool(valid),
        "fully_durable": len(valid) >= obj["replication"],
        "replicas": replicas
    }

def repair_all(user_id: str) -> list:
    repaired = []
    t0 = time.time()
    with lock:
        states = statuses(user_id)
        policy = get_policy(user_id)
        if not policy.get("auto_repair", 1):
            return []
        for obj in owned_objects(user_id):
            v = valid_nodes(obj, states)
            if not v:
                continue
            source = path_for(obj["object_id"], v[0])
            for node in NODE_NAMES:
                if len(v) >= obj["replication"]:
                    break
                if states[node] != "healthy" or node in v:
                    continue
                dest = path_for(obj["object_id"], node)
                dest.parent.mkdir(parents=True, exist_ok=True)
                staging = dest.with_suffix(".repair")
                try:
                    shutil.copyfile(source, staging)
                    if sha256_file(staging) != obj["sha256"]:
                        raise OSError("Repair checksum mismatch")
                    staging.replace(dest)
                    v.append(node)
                    repaired.append({"object_id": obj["object_id"], "filename": obj["filename"], "node": node})
                except OSError:
                    pass
                finally:
                    try:
                        staging.unlink(missing_ok=True)
                    except Exception:
                        pass
            with db() as con:
                for node in NODE_NAMES:
                    p = path_for(obj["object_id"], node)
                    st = ("healthy" if node in v
                          else "failed" if states[node] != "healthy"
                          else "corrupted" if p.is_file()
                          else "unused")
                    con.execute("INSERT OR REPLACE INTO replicas VALUES(?,?,?,?)",
                                (obj["object_id"], node, st, now_ts()))
        if repaired:
            event(user_id, "AUTO_REPAIR", f"Repaired {len(repaired)} replica(s)", "warning")
    elapsed_ms = (time.time() - t0) * 1000
    with _metrics_lock:
        _repair_log.append((time.time(), elapsed_ms, len(repaired)))
    return repaired

def rebalance_nodes(user_id: str) -> dict:
    """Redistribute objects so nodes have more even utilization."""
    with lock:
        states = statuses(user_id)
        objs = owned_objects(user_id)
        if not objs:
            return {"moved": 0, "details": []}
        node_sizes: dict = {}
        for node in NODE_NAMES:
            total = 0
            for obj in objs:
                p = path_for(obj["object_id"], node)
                if p.is_file():
                    total += p.stat().st_size
            node_sizes[node] = total
        moves = []
        for obj in objs:
            v = valid_nodes(obj, states)
            if len(v) < 2:
                continue
            # Find least-loaded healthy node not holding this object
            candidates = [n for n in NODE_NAMES if states[n] == "healthy" and n not in v]
            if not candidates:
                continue
            max_node = max(v, key=lambda n: node_sizes.get(n, 0))
            min_cand = min(candidates, key=lambda n: node_sizes.get(n, 0))
            if node_sizes.get(max_node, 0) - node_sizes.get(min_cand, 0) < obj["size"] * 0.2:
                continue
            src = path_for(obj["object_id"], max_node)
            dst = path_for(obj["object_id"], min_cand)
            dst.parent.mkdir(parents=True, exist_ok=True)
            staging = dst.with_suffix(".rebalance")
            try:
                shutil.copyfile(src, staging)
                if sha256_file(staging) != obj["sha256"]:
                    raise OSError("Rebalance checksum failed")
                staging.replace(dst)
                src.unlink()
                node_sizes[max_node] = node_sizes.get(max_node, 0) - obj["size"]
                node_sizes[min_cand] = node_sizes.get(min_cand, 0) + obj["size"]
                moves.append({"object_id": obj["object_id"], "filename": obj["filename"],
                              "from": max_node, "to": min_cand, "bytes": obj["size"]})
            except OSError:
                try:
                    staging.unlink(missing_ok=True)
                except Exception:
                    pass
        if moves:
            event(user_id, "REBALANCE", f"Moved {len(moves)} replica(s) across nodes")
        return {"moved": len(moves), "details": moves}


# ─── Background Tasks ─────────────────────────────────────────────────────────
async def repair_loop():
    while True:
        await asyncio.sleep(30)
        with db() as con:
            owners = [r[0] for r in con.execute(
                "SELECT DISTINCT user_id FROM objects WHERE user_id IS NOT NULL")]
        for owner in owners:
            try:
                await run_in_threadpool(repair_all, owner)
            except OSError:
                event(owner, "REPAIR_ERROR",
                      "Automatic repair failed. Check disk space.", "error")

async def lock_cleanup_loop():
    while True:
        await asyncio.sleep(60)
        with db() as con:
            con.execute("DELETE FROM write_locks WHERE locked_at < ?", (time.time() - 300,))

@asynccontextmanager
async def lifespan(app):
    t1 = asyncio.create_task(repair_loop())
    t2 = asyncio.create_task(lock_cleanup_loop())
    yield
    t1.cancel(); t2.cancel()
    for t in [t1, t2]:
        try:
            await t
        except asyncio.CancelledError:
            pass


# ─── App ──────────────────────────────────────────────────────────────────────
app = FastAPI(title="NODEX", version="3.0.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=BASE / "frontend"), name="static")

class BodyLimit:
    def __init__(self, app):
        self.app = app
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        limit = MAX_UPLOAD + 2 * 1024 * 1024 if scope["path"] == "/api/upload" else 64 * 1024
        for name, value in scope.get("headers", []):
            if name.lower() == b"content-length":
                try:
                    if int(value) > limit:
                        response = JSONResponse({"detail": "Request exceeds the allowed size"}, status_code=413)
                        return await response(scope, receive, send)
                except (ValueError, TypeError):
                    pass
        total = 0
        async def bounded_receive():
            nonlocal total
            msg = await receive()
            total += len(msg.get("body", b""))
            if total > limit:
                raise HTTPException(413, "Request exceeds the allowed size")
            return msg
        await self.app(scope, bounded_receive, send)

app.add_middleware(BodyLimit)

@app.middleware("http")
async def local_boundary(request: Request, call_next):
    if request.url.hostname not in {"127.0.0.1", "localhost", "testserver"}:
        return JSONResponse({"detail": "This vault accepts local access only."}, status_code=400)
    origin = request.headers.get("origin")
    if request.method not in {"GET", "HEAD", "OPTIONS"} and origin and origin != str(request.base_url).rstrip("/"):
        return JSONResponse({"detail": "Cross-origin changes are not allowed."}, status_code=403)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Cache-Control"] = "no-store"
    return response


# ─── Pydantic Models ──────────────────────────────────────────────────────────
class AuthBody(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=6, max_length=128)

class GoogleBody(BaseModel):
    credential: str = Field(max_length=16384)

class PolicyBody(BaseModel):
    replication_factor: int = Field(ge=1, le=4, default=3)
    read_quorum: int = Field(ge=1, le=4, default=1)
    write_quorum: int = Field(ge=1, le=4, default=2)
    max_upload_bytes: int = Field(ge=1024, le=104857600, default=104857600)
    quota_bytes: int = Field(ge=1048576, le=10737418240, default=1073741824)
    auto_repair: int = Field(ge=0, le=1, default=1)
    versioning: int = Field(ge=0, le=1, default=0)

class TagsBody(BaseModel):
    tags: dict

class AdminRoleBody(BaseModel):
    role: str

class AdminSuspendBody(BaseModel):
    suspended: bool


# ─── Routes: Index & Config ───────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
def index():
    return (BASE / "frontend" / "index.html").read_text(encoding="utf-8")

@app.get("/api/auth/config")
def auth_config():
    return {
        "google_client_id": GOOGLE_CLIENT_ID,
        "max_upload_bytes": MAX_UPLOAD,
        "quota_bytes": USER_QUOTA,
        "app_name": "NODEX"
    }

@app.get("/api/auth/me")
def auth_me(request: Request):
    return public_user(current_user(request))


# ─── Auth ─────────────────────────────────────────────────────────────────────
@app.post("/api/auth/signup")
def signup(body: AuthBody, request: Request, response: Response):
    rate_limit(request)
    email = body.email.strip().lower()
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        raise HTTPException(400, "Enter a valid email address")
    # First user ever → superadmin
    with db() as con:
        count = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    role = "superadmin" if count == 0 else "user"
    uid = uuid.uuid4().hex
    try:
        with db() as con:
            con.execute(
                "INSERT INTO users(user_id,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                (uid, email, password_hash(body.password), role, now_ts()))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "An account with this email already exists")
    event(uid, "ACCOUNT", f"Account created (role={role})")
    with db() as con:
        row = con.execute("SELECT * FROM users WHERE user_id=?", (uid,)).fetchone()
    return new_session(row, response)

@app.post("/api/auth/login")
def login(body: AuthBody, request: Request, response: Response):
    rate_limit(request)
    with db() as con:
        row = con.execute("SELECT * FROM users WHERE email=?", (body.email.strip().lower(),)).fetchone()
    if not row or not row["password_hash"] or not verify_password(body.password, row["password_hash"]):
        raise HTTPException(401, "Invalid email or password")
    if row["is_suspended"]:
        raise HTTPException(403, "This account has been suspended. Contact your administrator.")
    return new_session(row, response)

@app.post("/api/auth/google")
def google_login(body: GoogleBody, request: Request, response: Response):
    rate_limit(request)
    if not GOOGLE_CLIENT_ID:
        raise HTTPException(503, "Google sign-in is not configured")
    try:
        from google.oauth2 import id_token
        from google.auth.transport.requests import Request as GoogleRequest
        info = id_token.verify_oauth2_token(body.credential, GoogleRequest(), GOOGLE_CLIENT_ID)
        if not info.get("email_verified") or not info.get("sub") or not info.get("email"):
            raise ValueError("Unverified")
    except Exception:
        raise HTTPException(401, "Google sign-in failed.")
    email, sub = info["email"].strip().lower(), info["sub"]
    with db() as con:
        row = con.execute("SELECT * FROM users WHERE google_sub=?", (sub,)).fetchone()
        if not row:
            if con.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
                raise HTTPException(409, "Email exists. Use your password.")
            count = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            role = "superadmin" if count == 0 else "user"
            uid = uuid.uuid4().hex
            con.execute("INSERT INTO users(user_id,email,google_sub,role,created_at) VALUES(?,?,?,?,?)",
                        (uid, email, sub, role, now_ts()))
            row = con.execute("SELECT * FROM users WHERE user_id=?", (uid,)).fetchone()
    return new_session(row, response)

@app.post("/api/auth/logout")
def logout(request: Request, response: Response):
    with db() as con:
        con.execute("DELETE FROM sessions WHERE token_hash=?",
                    (token_hash(request.cookies.get(SESSION_COOKIE, "")),))
    response.delete_cookie(SESSION_COOKIE)
    return {"success": True}


# ─── Health & Nodes ───────────────────────────────────────────────────────────
@app.get("/api/health")
def health(request: Request):
    states = statuses(current_user(request)["user_id"])
    return {"service": "online", "nodes": states,
            "healthy": sum(s == "healthy" for s in states.values()), "total": 4}

@app.get("/api/nodes")
def get_nodes(request: Request):
    uid = current_user(request)["user_id"]
    objs, states = owned_objects(uid), statuses(uid)
    result = []
    for node in NODE_NAMES:
        sizes, counts = [], 0
        for o in objs:
            p = path_for(o["object_id"], node)
            if p.is_file():
                try:
                    sizes.append(p.stat().st_size)
                    counts += 1
                except OSError:
                    pass
        used = sum(sizes)
        # Simulate heartbeat: if healthy, last beat is recent
        hb = now_ts() if states[node] == "healthy" else "N/A"
        result.append({
            "node": node,
            "label": NODE_LABELS[node],
            "status": states[node],
            "used_bytes": used,
            "capacity_bytes": NODE_CAPACITY,
            "utilization_pct": round(used / NODE_CAPACITY * 100, 2),
            "objects": counts,
            "heartbeat": hb
        })
    return result

@app.get("/api/stats")
def stats(request: Request):
    uid = current_user(request)["user_id"]
    objs = owned_objects(uid)
    ns = get_nodes(request)
    policy = get_policy(uid)
    dist = {n["node"]: n["used_bytes"] for n in ns}
    return {
        "objects": len(objs),
        "logical_bytes": sum(o["size"] for o in objs),
        "physical_bytes": sum(dist.values()),
        "node_bytes": dist,
        "quota_bytes": policy["quota_bytes"],
        "quota_used": sum(o["size"] for o in objs),
    }

@app.get("/api/events")
def get_events(request: Request, limit: int = Query(100, ge=1, le=500)):
    uid = current_user(request)["user_id"]
    with db() as con:
        return [dict(r) for r in con.execute(
            "SELECT * FROM events WHERE user_id=? ORDER BY id DESC LIMIT ?", (uid, limit))]


# ─── Objects ──────────────────────────────────────────────────────────────────
@app.get("/api/objects")
def get_objects(request: Request):
    uid = current_user(request)["user_id"]
    with lock:
        return [describe(o, statuses(uid)) for o in owned_objects(uid)]

@app.get("/api/objects/{object_id}")
def object_detail(object_id: str, request: Request):
    uid = current_user(request)["user_id"]
    with lock:
        return describe(owned_object(object_id, uid), statuses(uid))

@app.patch("/api/objects/{object_id}/tags")
def update_tags(object_id: str, body: TagsBody, request: Request):
    uid = current_user(request)["user_id"]
    owned_object(object_id, uid)
    with db() as con:
        con.execute("UPDATE objects SET tags=?,updated_at=? WHERE object_id=? AND user_id=?",
                    (json.dumps(body.tags), now_ts(), object_id, uid))
    event(uid, "METADATA", f"Tags updated for {object_id[:8]}")
    return {"success": True}

@app.post("/api/upload")
def upload(request: Request, user: dict = Depends(current_user), file: UploadFile = File(...),
           replication: int = Query(3, ge=1, le=4)):
    t0 = time.time()
    uid = user["user_id"]
    policy = get_policy(uid)
    oid = uuid.uuid4().hex
    filename = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_",
                      (file.filename or "unnamed"))[:200].strip(" .") or "unnamed"
    temp = DATA / f".upload_{oid}"
    created = []
    try:
        size = 0
        h = hashlib.sha256()
        with temp.open("wb") as out:
            while chunk := file.file.read(1024 * 1024):
                size += len(chunk)
                if size > policy["max_upload_bytes"]:
                    raise HTTPException(413, f"File exceeds your {policy['max_upload_bytes']//1048576} MB limit")
                h.update(chunk)
                out.write(chunk)
        checksum = h.hexdigest()
        with lock:
            # Write quorum check
            states = statuses(uid)
            available = [n for n in NODE_NAMES if states[n] == "healthy"]
            if len(available) < policy["write_quorum"]:
                raise HTTPException(503,
                    f"Write quorum of {policy['write_quorum']} requires at least "
                    f"{policy['write_quorum']} healthy nodes; only {len(available)} available.")
            if len(available) < replication:
                raise HTTPException(503,
                    f"Only {len(available)} healthy nodes; lower your replication factor.")
            existing = owned_objects(uid)
            if sum(o["size"] for o in existing) + size > policy["quota_bytes"]:
                raise HTTPException(413, "Storage quota exhausted. Delete files first.")
            if shutil.disk_usage(STORAGE).free < size * replication + 10 * 1024 * 1024:
                raise HTTPException(507, "Not enough disk space for requested replicas.")
            # Load-balance: pick least-used nodes
            available.sort(key=lambda n: sum(
                path_for(o["object_id"], n).stat().st_size
                for o in existing if path_for(o["object_id"], n).is_file()))
            selected = available[:replication]
            with db() as con:
                for node in selected:
                    dest = path_for(oid, node)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    created.append(dest)
                    shutil.copyfile(temp, dest)
                    if sha256_file(dest) != checksum:
                        raise OSError("Replica verification failed")
                    con.execute("INSERT INTO replicas VALUES(?,?,?,?)",
                                (oid, node, "healthy", now_ts()))
                con.execute(
                    "INSERT INTO objects(object_id,filename,size,content_type,sha256,"
                    "replication,version,tags,created_at,updated_at,user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    (oid, filename, size, file.content_type or "application/octet-stream",
                     checksum, replication, 1, "{}", now_ts(), now_ts(), uid))
                con.execute(
                    "INSERT INTO events(event_type,message,severity,created_at,user_id) VALUES(?,?,?,?,?)",
                    ("UPLOAD", f"{filename} stored with {replication} verified replicas",
                     "info", now_ts(), uid))
        elapsed = (time.time() - t0) * 1000
        record_latency(elapsed)
        record_throughput(size)
        return {"success": True, "object_id": oid, "filename": filename,
                "size": size, "nodes": selected, "sha256": checksum}
    except Exception as exc:
        for p in created:
            p.unlink(missing_ok=True)
        if isinstance(exc, OSError):
            raise HTTPException(507, "Upload failed. Check disk space.") from exc
        raise
    finally:
        temp.unlink(missing_ok=True)
        file.file.close()

@app.get("/api/download/{object_id}")
def download(object_id: str, request: Request):
    t0 = time.time()
    uid = current_user(request)["user_id"]
    policy = get_policy(uid)
    with lock:
        obj = owned_object(object_id, uid)
        states = statuses(uid)
        v = valid_nodes(obj, states)
        # Read quorum: need at least read_quorum healthy replicas
        if len(v) < policy["read_quorum"]:
            raise HTTPException(503,
                f"Read quorum of {policy['read_quorum']} not met. "
                f"Only {len(v)} verified copies available.")
        event(uid, "DOWNLOAD", f"{obj['filename']} downloaded")
    elapsed = (time.time() - t0) * 1000
    record_latency(elapsed)
    record_throughput(obj["size"])
    return FileResponse(path_for(object_id, v[0]),
                        media_type="application/octet-stream",
                        filename=obj["filename"])

@app.delete("/api/objects/{object_id}")
def delete_object(object_id: str, request: Request):
    uid = current_user(request)["user_id"]
    with lock:
        obj = owned_object(object_id, uid)
        with db() as con:
            for node in NODE_NAMES:
                path_for(obj["object_id"], node).unlink(missing_ok=True)
            con.execute("DELETE FROM replicas WHERE object_id=?", (object_id,))
            con.execute("DELETE FROM objects WHERE object_id=? AND user_id=?", (object_id, uid))
        event(uid, "DELETE", f"{obj['filename']} deleted", "warning")
    return {"success": True}


# ─── Node Control ─────────────────────────────────────────────────────────────
@app.post("/api/nodes/{node}/{action}")
def change_node(node: str, action: str, request: Request):
    uid = current_user(request)["user_id"]
    if node not in NODE_NAMES or action not in {"fail", "recover"}:
        raise HTTPException(404, "Node or action not found")
    with lock:
        with db() as con:
            con.execute("INSERT OR REPLACE INTO user_nodes VALUES(?,?,?)",
                        (uid, node, "failed" if action == "fail" else "healthy"))
        event(uid, "NODE",
              f"{NODE_LABELS[node]} {'failure simulated' if action == 'fail' else 'recovered'}",
              "error" if action == "fail" else "info")
        repaired = repair_all(uid)
    return {"success": True, "repaired": repaired}


# ─── Repair & Integrity ───────────────────────────────────────────────────────
@app.post("/api/repair")
def repair(request: Request):
    uid = current_user(request)["user_id"]
    t0 = time.time()
    repaired = repair_all(uid)
    elapsed = (time.time() - t0) * 1000
    return {"success": True, "repaired": repaired, "duration_ms": round(elapsed, 1)}

@app.get("/api/integrity")
def integrity_check(request: Request):
    """Full SHA-256 integrity scan of all objects for this user."""
    uid = current_user(request)["user_id"]
    with lock:
        states = statuses(uid)
        results = []
        for obj in owned_objects(uid):
            per_node = []
            for node in NODE_NAMES:
                p = path_for(obj["object_id"], node)
                exists = p.is_file()
                if not exists:
                    per_node.append({"node": node, "exists": False, "match": None, "checksum": None})
                    continue
                try:
                    actual = sha256_file(p)
                    match = actual == obj["sha256"]
                except OSError:
                    actual = None
                    match = False
                per_node.append({"node": node, "exists": True, "match": match, "checksum": actual})
            results.append({
                "object_id": obj["object_id"],
                "filename": obj["filename"],
                "expected_sha256": obj["sha256"],
                "nodes": per_node,
                "all_ok": all(n["match"] for n in per_node if n["exists"])
            })
    return results

@app.post("/api/corrupt/{object_id}/{node}")
def corrupt(object_id: str, node: str, request: Request):
    uid = current_user(request)["user_id"]
    with lock:
        obj = owned_object(object_id, uid)
        v = valid_nodes(obj, statuses(uid))
        if node not in v or len(v) < 2:
            raise HTTPException(409, "Corruption simulation requires ≥2 verified copies.")
        with path_for(object_id, node).open("r+b") as h:
            first = h.read(1)
            h.seek(0)
            h.write(bytes([first[0] ^ 255]) if first else b"X")
        event(uid, "CORRUPT", f"Replica on {node} deliberately corrupted for testing", "error")
        repaired = repair_all(uid)
    return {"success": True, "repaired": repaired}

@app.post("/api/simulate/network-failure/{node}")
def simulate_network_failure(node: str, request: Request):
    uid = current_user(request)["user_id"]
    if node not in NODE_NAMES:
        raise HTTPException(404, "Node not found")
    with lock:
        with db() as con:
            con.execute("INSERT OR REPLACE INTO user_nodes VALUES(?,?,?)", (uid, node, "failed"))
        event(uid, "NETWORK_FAILURE", f"Network failure simulated on {NODE_LABELS[node]}", "error")
    return {"success": True, "node": node, "status": "failed"}


# ─── Rebalancer ───────────────────────────────────────────────────────────────
@app.post("/api/rebalance")
def rebalance(request: Request):
    uid = current_user(request)["user_id"]
    result = rebalance_nodes(uid)
    return {"success": True, **result}


# ─── Policies ─────────────────────────────────────────────────────────────────
@app.get("/api/policies")
def get_policies(request: Request):
    uid = current_user(request)["user_id"]
    return get_policy(uid)

@app.put("/api/policies")
def set_policies(body: PolicyBody, request: Request):
    uid = current_user(request)["user_id"]
    with db() as con:
        con.execute(
            "INSERT OR REPLACE INTO policies VALUES(?,?,?,?,?,?,?,?)",
            (uid, body.replication_factor, body.read_quorum, body.write_quorum,
             body.max_upload_bytes, body.quota_bytes, body.auto_repair, body.versioning))
    event(uid, "POLICY", f"Policies updated: RF={body.replication_factor}, "
                         f"RQ={body.read_quorum}, WQ={body.write_quorum}")
    return {"success": True, **body.dict()}


# ─── Monitoring ───────────────────────────────────────────────────────────────
@app.get("/api/monitoring")
def monitoring(request: Request):
    uid = current_user(request)["user_id"]
    current_user(request)  # auth check
    now = time.time()
    window = 300  # last 5 minutes
    with _metrics_lock:
        recent_lat = [ms for ts, ms in _latency_log if now - ts < window]
        recent_thru = [b for ts, b in _throughput_log if now - ts < window]
        recent_repairs = [(ts, ms, cnt) for ts, ms, cnt in _repair_log if now - ts < 3600]

    avg_lat = round(sum(recent_lat) / len(recent_lat), 1) if recent_lat else 0
    p99_lat = round(sorted(recent_lat)[int(len(recent_lat) * 0.99)] if len(recent_lat) > 1 else avg_lat, 1)
    throughput_bps = sum(recent_thru) / window if recent_thru else 0

    with db() as con:
        fail_count = con.execute(
            "SELECT COUNT(*) FROM events WHERE user_id=? AND event_type IN ('NODE','CORRUPT','NETWORK_FAILURE') "
            "AND created_at > datetime('now','-1 hour')", (uid,)).fetchone()[0]
        repair_count = con.execute(
            "SELECT COUNT(*) FROM events WHERE user_id=? AND event_type='AUTO_REPAIR' "
            "AND created_at > datetime('now','-1 hour')", (uid,)).fetchone()[0]
        events_list = [dict(r) for r in con.execute(
            "SELECT * FROM events WHERE user_id=? ORDER BY id DESC LIMIT 50", (uid,))]

    return {
        "avg_latency_ms": avg_lat,
        "p99_latency_ms": p99_lat,
        "throughput_bps": round(throughput_bps, 1),
        "operations_last_5m": len(recent_lat),
        "failures_last_hour": fail_count,
        "repairs_last_hour": repair_count,
        "repair_history": [
            {"ts": ts, "duration_ms": round(ms, 1), "count": cnt}
            for ts, ms, cnt in recent_repairs
        ],
        "events": events_list
    }


# ─── Replication Map ──────────────────────────────────────────────────────────
@app.get("/api/replication-map")
def replication_map(request: Request):
    uid = current_user(request)["user_id"]
    with lock:
        states = statuses(uid)
        result = []
        for obj in owned_objects(uid):
            v = valid_nodes(obj, states)
            result.append({
                "object_id": obj["object_id"],
                "filename": obj["filename"],
                "size": obj["size"],
                "sha256": obj["sha256"],
                "replication": obj["replication"],
                "verified_replicas": len(v),
                "replica_locations": v,
                "replica_details": [
                    {"node": n, "label": NODE_LABELS[n], "healthy": n in v,
                     "exists": path_for(obj["object_id"], n).is_file()}
                    for n in NODE_NAMES
                ]
            })
    return result


# ─── Consistency ──────────────────────────────────────────────────────────────
@app.post("/api/lock/{object_id}")
def acquire_lock(object_id: str, request: Request):
    uid = current_user(request)["user_id"]
    owned_object(object_id, uid)
    with db() as con:
        existing = con.execute(
            "SELECT * FROM write_locks WHERE object_id=?", (object_id,)).fetchone()
        if existing and existing["locked_by"] != uid and existing["locked_at"] > time.time() - 300:
            raise HTTPException(409, f"Object is locked by another operation.")
        con.execute("INSERT OR REPLACE INTO write_locks VALUES(?,?,?)",
                    (object_id, uid, time.time()))
    return {"success": True, "locked": True}

@app.delete("/api/lock/{object_id}")
def release_lock(object_id: str, request: Request):
    uid = current_user(request)["user_id"]
    with db() as con:
        con.execute("DELETE FROM write_locks WHERE object_id=? AND locked_by=?", (object_id, uid))
    return {"success": True, "locked": False}

@app.get("/api/versions/{object_id}")
def object_versions(object_id: str, request: Request):
    uid = current_user(request)["user_id"]
    obj = owned_object(object_id, uid)
    # In this implementation, version is stored per object
    return {
        "object_id": object_id,
        "filename": obj["filename"],
        "current_version": obj["version"],
        "versioning_enabled": bool(get_policy(uid).get("versioning", 0)),
        "note": "Full version history requires versioning=1 in policies"
    }


# ─── Reset ────────────────────────────────────────────────────────────────────
@app.delete("/api/reset")
def reset(request: Request):
    uid = current_user(request)["user_id"]
    with lock:
        for obj in owned_objects(uid):
            for node in NODE_NAMES:
                path_for(obj["object_id"], node).unlink(missing_ok=True)
        with db() as con:
            uids = [r["object_id"] for r in con.execute(
                "SELECT object_id FROM objects WHERE user_id=?", (uid,))]
            for oid in uids:
                con.execute("DELETE FROM replicas WHERE object_id=?", (oid,))
            con.execute("DELETE FROM objects WHERE user_id=?", (uid,))
            con.execute("DELETE FROM events WHERE user_id=?", (uid,))
            con.execute("DELETE FROM user_nodes WHERE user_id=?", (uid,))
        event(uid, "RESET", "Vault cleared", "warning")
    return {"success": True}


# ─── Admin Endpoints ─────────────────────────────────────────────────────────
@app.get("/api/admin/users")
def admin_list_users(request: Request):
    require_admin(request)
    with db() as con:
        rows = con.execute(
            "SELECT u.user_id, u.email, u.role, u.created_at, u.is_suspended, "
            "COUNT(o.object_id) as obj_count, COALESCE(SUM(o.size),0) as total_bytes "
            "FROM users u LEFT JOIN objects o ON o.user_id=u.user_id "
            "GROUP BY u.user_id ORDER BY u.created_at DESC"
        ).fetchall()
    return [dict(r) for r in rows]

@app.get("/api/admin/stats")
def admin_global_stats(request: Request):
    require_admin(request)
    with db() as con:
        users = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        objects = con.execute("SELECT COUNT(*) FROM objects").fetchone()[0]
        total_bytes = con.execute("SELECT COALESCE(SUM(size),0) FROM objects").fetchone()[0]
        events_today = con.execute(
            "SELECT COUNT(*) FROM events WHERE created_at > datetime('now','-1 day')").fetchone()[0]
        suspended = con.execute("SELECT COUNT(*) FROM users WHERE is_suspended=1").fetchone()[0]
    # Node usage across all objects
    node_usage = {}
    for node in NODE_NAMES:
        node_dir = STORAGE / node
        total = sum(f.stat().st_size for f in node_dir.rglob("*") if f.is_file()) if node_dir.exists() else 0
        node_usage[node] = total
    return {
        "total_users": users,
        "total_objects": objects,
        "total_bytes": total_bytes,
        "events_today": events_today,
        "suspended_users": suspended,
        "node_usage": node_usage
    }

@app.get("/api/admin/events")
def admin_events(request: Request, limit: int = Query(200, ge=1, le=1000)):
    require_admin(request)
    with db() as con:
        return [dict(r) for r in con.execute(
            "SELECT e.*, u.email FROM events e LEFT JOIN users u ON u.user_id=e.user_id "
            "ORDER BY e.id DESC LIMIT ?", (limit,))]

@app.patch("/api/admin/users/{user_id}/role")
def admin_set_role(user_id: str, body: AdminRoleBody, request: Request):
    actor = require_superadmin(request)
    if body.role not in ("user", "admin", "superadmin"):
        raise HTTPException(400, "Invalid role")
    if user_id == actor["user_id"]:
        raise HTTPException(400, "Cannot change your own role")
    with db() as con:
        con.execute("UPDATE users SET role=? WHERE user_id=?", (body.role, user_id))
    event(actor["user_id"], "ADMIN", f"Changed role of {user_id[:8]} to {body.role}")
    return {"success": True}

@app.patch("/api/admin/users/{user_id}/suspend")
def admin_suspend(user_id: str, body: AdminSuspendBody, request: Request):
    actor = require_admin(request)
    if user_id == actor["user_id"]:
        raise HTTPException(400, "Cannot suspend yourself")
    with db() as con:
        row = con.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        if not row:
            raise HTTPException(404, "User not found")
        if row["role"] == "superadmin":
            raise HTTPException(403, "Cannot suspend a superadmin")
        con.execute("UPDATE users SET is_suspended=? WHERE user_id=?",
                    (1 if body.suspended else 0, user_id))
    action = "suspended" if body.suspended else "unsuspended"
    event(actor["user_id"], "ADMIN", f"User {user_id[:8]} {action}", "warning")
    return {"success": True}

@app.delete("/api/admin/users/{user_id}")
def admin_delete_user(user_id: str, request: Request):
    actor = require_superadmin(request)
    if user_id == actor["user_id"]:
        raise HTTPException(400, "Cannot delete yourself")
    with db() as con:
        row = con.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        if not row:
            raise HTTPException(404, "User not found")
    # Delete all their data
    with lock:
        with db() as con:
            objs = con.execute("SELECT * FROM objects WHERE user_id=?", (user_id,)).fetchall()
            for obj in objs:
                for node in NODE_NAMES:
                    try:
                        path_for(obj["object_id"], node).unlink(missing_ok=True)
                    except Exception:
                        pass
                con.execute("DELETE FROM replicas WHERE object_id=?", (obj["object_id"],))
            con.execute("DELETE FROM objects WHERE user_id=?", (user_id,))
            con.execute("DELETE FROM events WHERE user_id=?", (user_id,))
            con.execute("DELETE FROM user_nodes WHERE user_id=?", (user_id,))
            con.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
            con.execute("DELETE FROM policies WHERE user_id=?", (user_id,))
            con.execute("DELETE FROM users WHERE user_id=?", (user_id,))
    event(actor["user_id"], "ADMIN", f"Deleted user account {row['email']}", "error")
    return {"success": True}

@app.get("/api/admin/users/{user_id}/objects")
def admin_user_objects(user_id: str, request: Request):
    require_admin(request)
    with db() as con:
        row = con.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        if not row:
            raise HTTPException(404, "User not found")
    with lock:
        states = statuses(user_id)
        return [describe(o, states) for o in owned_objects(user_id)]
