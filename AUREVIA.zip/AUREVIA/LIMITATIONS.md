# NODEX — Technical Notes & System Boundaries

This document details the architectural boundaries, implemented enhancements, and operational scope of the NODEX platform.

---

## Implemented Enhancements (v3.0.0)

1. **Brand & Visuals**: Complete transition to NODEX enterprise dark-mode theme featuring high-contrast layout, responsive sidebar, real-time health indicator, and modular glassmorphic dashboards.
2. **12 Core Vault Sections**: Full implementation of Dashboard, Object Explorer, Node Manager, Replication Map, Failure Simulator, Auto-Repair, Integrity Checker, Rebalancer, Consistency/Locks, Policy Manager, Real-time Monitoring, and Architectural Blueprints.
3. **Role-Based Access Control (RBAC)**: Integrated 3-tier user hierarchy (`user`, `admin`, `superadmin`). The first account created automatically receives `superadmin` privileges with user promotion, suspension, and account purging capabilities.
4. **SeaweedFS-Inspired Rebalancer**: Real-time load redistribution that evaluates node storage disparity and migrates replicas from overloaded nodes to under-utilized nodes while validating SHA-256 integrity.
5. **Consistency & Locking**: Concurrency control via server-managed write locks, quorum validation for read ($R$) and write ($W$) operations, and object version tracking.
6. **Live Telemetry & Monitoring**: In-memory ring-buffer tracking average/P99 latencies, byte throughput, failure incident counts, repair execution times, and comprehensive audit logs.
7. **Auto-Repair Engine**: 30-second asynchronous background scrub accompanied by instant on-demand repair hooks after simulated node failures or corruption events.

---

## Operational Scope & Environmental Boundaries

1. **Single Physical Host**: The four storage nodes (`node1` through `node4`) are simulated as separate directories on the local machine filesystem. Hardware failure, whole-disk corruption, or catastrophic OS loss impacts all replicas. In a multi-server production environment (such as native SeaweedFS), nodes are distributed across physical racks and distinct network subnets.
2. **Local Loopback Boundary**: The application is configured to run on `127.0.0.1` / `localhost` by default with HTTP session cookies and strict local CORS origin boundaries. Production network deployment requires TLS termination (HTTPS) and an external reverse proxy (e.g. NGINX or Traefik).
3. **Storage Encryption**: Cryptographic integrity is verified using SHA-256 hashes on write and repair, but chunks on disk are unencrypted at rest. Enterprise production storage requires volume-level AES-256 or envelope encryption.
4. **Single-Process SQLite**: Metadata is stored in a SQLite database with timeout-backed concurrency handling and write-lock table isolation. Workloads scaling to millions of concurrent writes would benefit from distributed key-value stores or SeaweedFS Master Raft clusters.
5. **Recovery Prerequisite**: Auto-repair requires at least one healthy verified replica surviving in the cluster. If all nodes containing copies of an object are corrupted or wiped before repair, the object cannot be recovered.
