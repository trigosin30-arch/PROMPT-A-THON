# NODEX — Enterprise Distributed Object Storage

**NODEX** is a fault-tolerant, self-healing distributed object storage engine inspired by the architecture of **SeaweedFS**. Built for enterprise workloads, it separates metadata management from physical chunk storage across simulated nodes, enforcing cryptographic SHA-256 data integrity, configurable read/write quorums, active auto-repair loops, and automated node rebalancing.

---

## Architecture (Inspired by SeaweedFS)

NODEX adopts SeaweedFS's core design philosophy:
1. **Metadata Separation (Master Server)**: Handled by FastAPI and SQLite (`storageatdell.db`), tracking object lookup keys, hashes, versions, metadata tags, replica placement maps, and audit logs without reading file payloads.
2. **Storage Nodes (Volume Servers)**: Data chunks are distributed across physical node folders (`storage/node1` through `storage/node4`). Each node simulates an independent storage chassis with capacity limits, heartbeat tracking, and local filesystem storage.
3. **Self-Healing & Auto-Repair**: A continuous background scrubber checks replica health every 30 seconds. If a replica is missing or corrupted, a healthy copy is replicated across surviving nodes.
4. **Rebalancing (Vacuum Simulation)**: Inspired by SeaweedFS vacuum and balancing routines, the engine detects uneven node disk consumption and transparently migrates replicas to least-loaded nodes.
5. **Strict Quorums**: Configurable read quorum ($R$) and write quorum ($W$) ensure strong consistency and durability before operations are acknowledged.

---

## 12 Core Vault Sections

1. **Dashboard**: High-level cluster health, active/total nodes, storage capacity utilization, logical vs. physical byte counts, object count, and live health pill.
2. **Object Explorer**: Upload files with custom replication factors (1–4), browse objects, download, delete, inspect metadata, view SHA-256 checksums, and edit custom JSON tags.
3. **Node Manager**: Inspect Node 01 through Node 04, status (`healthy` / `failed`), capacity, simulated heartbeats, object counts, and a comprehensive breakdown of how node states directly impact storage, quorum, and durability.
4. **Replication**: Interactive visual replica matrix showing exactly which storage nodes hold verified copies of every object in the vault.
5. **Failure Simulator**: Test cluster resilience in real time:
   - Kill any node to simulate hardware outage.
   - Inject bit-flip corruption into a single replica.
   - Simulate sudden network partition.
6. **Auto Repair**: Trigger immediate on-demand repair or watch the 30-second background worker detect damaged replicas, copy from a healthy node, verify SHA-256 integrity, and restore durability.
7. **Integrity Checker**: Full cryptographic SHA-256 sweep across all physical replica files to detect silent bit rot and data tampering.
8. **Rebalancer**: Automated load equalizer that redistributes replicas from overloaded nodes to under-utilized nodes.
9. **Consistency**: Object write locks for concurrency control, object versioning tracking, and quorum validation.
10. **Policies**: User-configurable cluster settings:
    - Replication factor (1–4)
    - Read quorum ($R$)
    - Write quorum ($W$)
    - Max upload size & user quota limits
    - Toggle automatic repair & versioning
11. **Monitoring**: Performance analytics including average and P99 latency, real-time throughput (bytes/sec), recent failure counts, repair duration metrics, and audit event logs.
12. **Architecture**: Detailed visual reference diagram explaining the Master/Node architecture, client flow, and auto-repair pipelines.

---

## Role-Based Access Control (RBAC)

NODEX features a 3-tier enterprise role hierarchy:
- **User**: Isolated personal storage vault, policy tuning, upload/download, simulation tools.
- **Admin**: All User capabilities + global cluster statistics, user directory inspection, and ability to suspend/unsuspend accounts.
- **SuperAdmin**: Full system authority: change user roles (User $\leftrightarrow$ Admin $\leftrightarrow$ SuperAdmin) and purge accounts with their associated replicas.
*Note: The first registered account on a clean database automatically receives the `SuperAdmin` role.*

---

## Quick Start

### 1. Launch with Batch Script (Windows)
Double-click `RUN_VAULT.bat` or run:
```cmd
RUN_VAULT.bat
```
This automatically sets up the Python virtual environment (`venv`), installs dependencies from `backend/requirements.txt`, and boots the server at `http://127.0.0.1:8000`.

### 2. Manual Startup
```bash
python -m venv venv
venv\Scripts\activate.bat
pip install -r backend/requirements.txt
uvicorn backend.main:app --host 127.0.0.1 --port 8000
```
Open [http://127.0.0.1:8000](http://127.0.0.1:8000) in your browser.

---

## Running the Test Suite

Regression tests cover authentication, access isolation, replication mapping, integrity verification, auto-repair, rebalancing, policies, quorums, and RBAC:
```cmd
venv\Scripts\python.exe -m unittest test_vault -v
```

---

## Technology Stack
- **Backend**: Python 3, FastAPI, Uvicorn, SQLite3, Starlette.
- **Frontend**: Vanilla HTML5, CSS3 (Dark Mode, Glassmorphism, Responsive CSS Grid/Flexbox), Vanilla JavaScript (Zero external framework dependencies).
- **Design Inspiration**: Dell Enterprise Design System & SeaweedFS distributed architecture.
