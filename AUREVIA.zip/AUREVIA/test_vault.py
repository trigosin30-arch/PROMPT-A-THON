"""NODEX regression checks using a disposable database and storage directory."""
import hashlib
import http.cookiejar
import json
import os
from pathlib import Path
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent

class VaultTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix="nodex-test-", ignore_cleanup_errors=True)
        cls.folder = Path(cls.temp.name)
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            cls.port = sock.getsockname()[1]
        cls.url = f"http://127.0.0.1:{cls.port}"
        env = {
            **os.environ,
            "NODEX_DATA_DIR": str(cls.folder / "data"),
            "NODEX_STORAGE_DIR": str(cls.folder / "storage"),
            "SAD_DATA_DIR": str(cls.folder / "data"),
            "SAD_STORAGE_DIR": str(cls.folder / "storage"),
            "AUREVIA_DATA_DIR": str(cls.folder / "data"),
            "AUREVIA_STORAGE_DIR": str(cls.folder / "storage"),
        }
        cls.log = (cls.folder / "server.log").open("w+")
        cls.process = subprocess.Popen([sys.executable, "-m", "uvicorn", "backend.main:app", "--host", "127.0.0.1", "--port", str(cls.port)], cwd=ROOT, env=env, stdout=cls.log, stderr=cls.log)
        for _ in range(100):
            try:
                urllib.request.urlopen(cls.url, timeout=1).close()
                break
            except (OSError, urllib.error.URLError):
                time.sleep(.1)
        else:
            cls.process.terminate()
            cls.log.seek(0)
            raise RuntimeError(cls.log.read())
        cls.a = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        cls.b = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        cls.anon = urllib.request.build_opener()
        # First user is superadmin
        cls.uid_a = cls.request(cls.a, "/api/auth/signup", "POST", {"email": "a@example.com", "password": "test-password"})[1]["user"]["user_id"]
        # Second user is standard user
        cls.uid_b = cls.request(cls.b, "/api/auth/signup", "POST", {"email": "b@example.com", "password": "test-password"})[1]["user"]["user_id"]

    @classmethod
    def tearDownClass(cls):
        cls.process.terminate()
        try:
            cls.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            cls.process.kill()
            cls.process.wait()
        cls.log.close()
        try:
            cls.temp.cleanup()
        except OSError:
            pass

    @classmethod
    def get_db_path(cls) -> Path:
        for name in ["nodex.db", "storageatdell.db", "aurevia.db"]:
            p = cls.folder / "data" / name
            if p.exists():
                return p
        return cls.folder / "data" / "nodex.db"

    @classmethod
    def request(cls, client, path, method="GET", data=None, headers=None):
        headers = headers or {}
        if isinstance(data, dict):
            data = json.dumps(data).encode()
            headers = {"Content-Type": "application/json", **headers}
        req = urllib.request.Request(cls.url + path, data=data, method=method, headers=headers)
        try:
            response = client.open(req, timeout=20)
        except urllib.error.HTTPError as exc:
            response = exc
        with response:
            raw = response.read()
            try:
                payload = json.loads(raw)
            except (ValueError, UnicodeDecodeError):
                payload = raw
            return response.status, payload

    def upload(self, client=None, content=b"original file bytes", replication=3):
        boundary = "NODEXTestBoundary"
        data = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="sample.txt"\r\nContent-Type: text/plain\r\n\r\n'.encode() + content + f'\r\n--{boundary}--\r\n'.encode())
        code, result = self.request(client or self.a, f"/api/upload?replication={replication}", "POST", data, {"Content-Type": f"multipart/form-data; boundary={boundary}"})
        self.assertEqual(code, 200, result)
        return result["object_id"]

    def test_01_access_isolation(self):
        oid = self.upload()
        self.assertEqual(self.request(self.a, f"/api/download/{oid}")[1], b"original file bytes")
        self.assertEqual(self.request(self.b, "/api/objects")[1], [])
        for path, method in [(f"/api/objects/{oid}", "GET"), (f"/api/download/{oid}", "GET"), (f"/api/objects/{oid}", "DELETE"), (f"/api/corrupt/{oid}/node1", "POST")]:
            self.assertEqual(self.request(self.b, path, method)[0], 404)
        self.assertEqual(self.request(self.anon, "/api/objects")[0], 401)
        self.assertEqual(self.request(self.anon, "/api/upload", "POST", b"")[0], 401)

    def test_02_verify_does_not_modify(self):
        oid = self.upload()
        before = (self.folder / "storage" / "node1" / oid).read_bytes()
        result = self.request(self.a, f"/api/objects/{oid}")[1]
        self.assertTrue(result["fully_durable"])
        self.assertEqual((self.folder / "storage" / "node1" / oid).read_bytes(), before)

    def test_03_fail_repair_and_recover(self):
        oid = self.upload()
        self.assertEqual(self.request(self.a, "/api/nodes/node1/fail", "POST")[0], 200)
        self.assertEqual(self.request(self.b, "/api/health")[1]["healthy"], 4)
        self.assertTrue(self.request(self.a, f"/api/objects/{oid}")[1]["healthy"])
        self.request(self.a, "/api/nodes/node1/recover", "POST")
        self.assertEqual(self.request(self.a, "/api/health")[1]["healthy"], 4)

    def test_04_corruption_and_last_copy_guard(self):
        oid = self.upload(replication=1)
        detail = self.request(self.a, f"/api/objects/{oid}")[1]
        node = detail["verified_nodes"][0]
        self.assertEqual(self.request(self.a, f"/api/corrupt/{oid}/{node}", "POST")[0], 409)
        oid2 = self.upload(content=b"", replication=3)
        detail = self.request(self.a, f"/api/objects/{oid2}")[1]
        node = detail["verified_nodes"][0]
        self.assertEqual(self.request(self.a, f"/api/corrupt/{oid2}/{node}", "POST")[0], 200)
        self.assertTrue(self.request(self.a, f"/api/objects/{oid2}")[1]["healthy"])
        self.assertEqual(self.request(self.a, f"/api/download/{oid2}")[1], b"")

    def test_05_invalid_inputs_and_origin(self):
        self.assertEqual(self.request(self.a, "/api/events?limit=-1")[0], 422)
        self.assertEqual(self.request(self.a, "/api/nodes/other/fail", "POST")[0], 404)
        self.assertEqual(self.request(self.a, "/api/reset", "DELETE", headers={"Origin": "https://other.example"})[0], 403)
        self.assertEqual(self.request(self.a, "/api/auth/login", "POST", b"x" * 70000, {"Content-Type": "application/json"})[0], 413)

    def test_06_clear_only_current_account(self):
        oid = self.upload(self.b)
        self.assertEqual(self.request(self.a, "/api/reset", "DELETE")[0], 200)
        self.assertEqual(self.request(self.a, "/api/objects")[1], [])
        self.assertEqual(self.request(self.b, f"/api/download/{oid}")[0], 200)
        events = self.request(self.a, "/api/events")[1]
        self.assertTrue(all(e["user_id"] == self.uid_a for e in events))

    def test_07_legacy_objects_not_exposed(self):
        with sqlite3.connect(self.get_db_path()) as con:
            con.execute("INSERT INTO objects(object_id,filename,size,content_type,sha256,replication,created_at,updated_at,user_id) VALUES(?,?,?,?,?,?,?,?,?)",
                        ("0" * 32, "legacy", 0, "text/plain", hashlib.sha256(b"").hexdigest(), 1, "2020-01-01", "2020-01-01", None))
        self.assertEqual(self.request(self.a, "/api/objects/" + "0" * 32)[0], 404)
        self.assertEqual(self.request(self.b, "/api/objects/" + "0" * 32)[0], 404)

    def test_08_expiration_and_logout(self):
        with sqlite3.connect(self.get_db_path()) as con:
            con.execute("UPDATE sessions SET expires_at=0 WHERE user_id=?", (self.uid_a,))
        self.assertEqual(self.request(self.a, "/api/auth/me")[0], 401)
        self.assertEqual(self.request(self.a, "/api/auth/login", "POST", {"email": "a@example.com", "password": "test-password"})[0], 200)
        self.assertEqual(self.request(self.a, "/api/auth/me")[0], 200)

    def test_09_replication_map_and_integrity(self):
        oid = self.upload()
        code, rmap = self.request(self.a, "/api/replication-map")
        self.assertEqual(code, 200)
        self.assertTrue(any(item["object_id"] == oid for item in rmap))
        code, scan = self.request(self.a, "/api/integrity")
        self.assertEqual(code, 200)
        self.assertTrue(any(item["object_id"] == oid and item["all_ok"] for item in scan))

    def test_10_policies_and_monitoring(self):
        code, pol = self.request(self.a, "/api/policies")
        self.assertEqual(code, 200)
        self.assertIn("replication_factor", pol)
        code, mon = self.request(self.a, "/api/monitoring")
        self.assertEqual(code, 200)
        self.assertIn("avg_latency_ms", mon)

    def test_11_admin_access(self):
        # User A is superadmin
        code, users = self.request(self.a, "/api/admin/users")
        self.assertEqual(code, 200)
        self.assertEqual(len(users), 2)
        code, stats = self.request(self.a, "/api/admin/stats")
        self.assertEqual(code, 200)
        self.assertIn("total_users", stats)
        # User B is regular user, should be forbidden
        code, _ = self.request(self.b, "/api/admin/users")
        self.assertEqual(code, 403)

if __name__ == "__main__":
    unittest.main(verbosity=2)
