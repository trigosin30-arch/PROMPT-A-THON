// NODEX — Full Application JavaScript
// Inspired by SeaweedFS architecture

'use strict';

// ─── State ─────────────────────────────────────────────────────────────────
let authMode = 'login';
let currentUser = null;
let objectCache = [];
let nodeCache = [];
let uploadBusy = false;
let refreshBusy = false;
let lastUploadFocus = null;

// ─── DOM Helpers ────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = n => {
  n = Number(n || 0);
  const u = ['B','KB','MB','GB','TB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i ? 1 : 0)} ${u[i]}`;
};
const fmtTime = iso => {
  try { return new Date(iso).toLocaleString(); } catch { return iso || '—'; }
};
const fmtMs = ms => ms < 1 ? '<1 ms' : ms < 1000 ? `${Math.round(ms)} ms` : `${(ms/1000).toFixed(1)} s`;
const fmtBps = bps => bps === 0 ? '0 B/s' : fmt(bps) + '/s';

function toast(msg, type = '') {
  const t = $('toast');
  t.textContent = msg;
  t.className = `toast show${type ? ' ' + type : ''}`;
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ─── API ────────────────────────────────────────────────────────────────────
async function api(url, opts = {}) {
  const options = { credentials: 'same-origin', ...opts };
  let r;
  try {
    r = await fetch(url, options);
  } catch (e) {
    throw new Error('NODEX server is not running. Start RUN_VAULT.bat and open http://127.0.0.1:8000');
  }
  const d = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (r.status === 401 && !url.startsWith('/api/auth/')) {
      showAuth('login');
      setAuthMsg('Your session expired. Please sign in again.');
    }
    throw new Error(typeof d.detail === 'string' ? d.detail : `Error ${r.status}`);
  }
  return d;
}

// ─── Navigation ─────────────────────────────────────────────────────────────
function showLanding() {
  $('landingPage').classList.remove('hidden');
  $('authScreen').classList.add('hidden');
  $('appShell').classList.add('hidden');
}

function showAuth(mode = 'login') {
  authMode = mode;
  $('landingPage').classList.add('hidden');
  $('authScreen').classList.remove('hidden');
  $('appShell').classList.add('hidden');
  updateAuthUI();
  $('authEmail').focus();
}

function setAuthMsg(msg, ok = false) {
  const el = $('authMessage');
  el.textContent = msg || '';
  el.className = 'auth-msg' + (ok ? ' success' : '');
}

function updateAuthUI() {
  const isLogin = authMode === 'login';
  $('authTitle').textContent = isLogin ? 'Sign in' : 'Create account';
  $('authSubmit').textContent = isLogin ? 'Sign In' : 'Create Account';
  $('authSwitch').textContent = isLogin ? 'New here? Create an account' : 'Already have an account? Sign in';
  $('authPassword').autocomplete = isLogin ? 'current-password' : 'new-password';
  $('authHint').textContent = isLogin ? 'First account is auto-promoted to SuperAdmin.' : 'First account created becomes SuperAdmin automatically.';
  setAuthMsg('');
}

function toggleAuthMode() {
  authMode = authMode === 'login' ? 'signup' : 'login';
  $('authPassword').value = '';
  updateAuthUI();
}

function scrollToId(id) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
}

function toggleSidebar() {
  document.querySelector('.app-shell').classList.toggle('sidebar-collapsed');
}

// ─── Auth ───────────────────────────────────────────────────────────────────
$('authForm').addEventListener('submit', async e => {
  e.preventDefault();
  const email = $('authEmail').value.trim();
  const password = $('authPassword').value;
  if (!email || !password) { setAuthMsg('Enter your email and password.'); return; }
  const btn = $('authSubmit');
  btn.disabled = true;
  setAuthMsg(authMode === 'login' ? 'Signing in…' : 'Creating account…');
  try {
    const d = await api(`/api/auth/${authMode}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    currentUser = d.user;
    showApp(d.user);
  } catch (e) {
    setAuthMsg(e.message);
  } finally {
    btn.disabled = false;
  }
});

async function checkAuth() {
  try {
    const user = await api('/api/auth/me');
    currentUser = user;
    showApp(user);
  } catch {
    showLanding();
  }
}

function showApp(user) {
  currentUser = user;
  $('landingPage').classList.add('hidden');
  $('authScreen').classList.add('hidden');
  $('appShell').classList.remove('hidden');

  // User info in sidebar
  $('sideUserEmail').textContent = user.email;
  $('sideUserAvatar').textContent = user.email[0].toUpperCase();
  const roleBadge = $('sideUserRole');
  roleBadge.textContent = user.role;
  roleBadge.className = `user-role-badge ${user.role}`;

  // Show admin/superadmin nav
  if (user.role === 'admin' || user.role === 'superadmin') {
    $('adminNav').classList.remove('hidden');
  }
  if (user.role === 'superadmin') {
    $('superAdminNav').classList.remove('hidden');
  }

  refreshAll();
  setInterval(() => { if (!document.hidden) refreshAll(); }, 30000);
}

async function logout() {
  try { await api('/api/auth/logout', { method: 'POST' }); } catch {}
  location.reload();
}

// ─── Tabs ───────────────────────────────────────────────────────────────────
const TAB_LABELS = {
  dashboard: 'Dashboard', objects: 'Object Explorer', nodes: 'Node Manager',
  replication: 'Replication', simulator: 'Failure Simulator', autorepair: 'Auto Repair',
  integrity: 'Integrity Checker', rebalancer: 'Rebalancer', consistency: 'Consistency',
  policies: 'Policies', monitoring: 'Monitoring', architecture: 'Architecture',
  admin: 'Admin Panel', superadmin: 'Super Admin'
};

function showTab(id) {
  document.querySelectorAll('.tab').forEach(x => x.classList.remove('active-tab'));
  document.querySelectorAll('.nav').forEach(x => x.classList.remove('active'));
  const tab = $(id);
  if (tab) tab.classList.add('active-tab');
  const nav = $(`nav-${id}`);
  if (nav) nav.classList.add('active');
  $('headerBreadcrumb').textContent = TAB_LABELS[id] || id;

  // Lazy load data for specific tabs
  if (id === 'replication') loadReplicationMap();
  if (id === 'simulator') renderSimulator();
  if (id === 'consistency') loadConsistency();
  if (id === 'policies') loadPolicies();
  if (id === 'monitoring') loadMonitoring();
  if (id === 'rebalancer') renderRebalancerBars();
  if (id === 'autorepair') renderRepairStatus();
  if (id === 'admin') loadAdminData();
  if (id === 'superadmin') loadSuperAdminData();
}

// ─── Refresh All ────────────────────────────────────────────────────────────
async function refreshAll() {
  if (refreshBusy || $('appShell').classList.contains('hidden')) return;
  refreshBusy = true;
  try {
    const [stats, nodes, objects, health] = await Promise.all([
      api('/api/stats'), api('/api/nodes'), api('/api/objects'), api('/api/health')
    ]);
    nodeCache = nodes;
    objectCache = objects;

    // Header health pill
    const dot = $('healthDot');
    const txt = $('healthText');
    if (health.healthy === health.total) {
      dot.className = 'health-dot'; txt.textContent = 'All Nodes Online';
    } else if (health.healthy > 0) {
      dot.className = 'health-dot warn'; txt.textContent = `${health.healthy}/${health.total} Nodes`;
    } else {
      dot.className = 'health-dot err'; txt.textContent = 'All Nodes Down';
    }

    // Dashboard stats
    $('statObjects').textContent = stats.objects;
    $('statObjectsNote').textContent = fmt(stats.logical_bytes) + ' logical';
    $('statPhysical').textContent = fmt(stats.physical_bytes);
    $('statNodes').textContent = `${health.healthy}/${health.total}`;
    const quotaPct = Math.round(stats.quota_used / stats.quota_bytes * 100);
    $('statQuota').textContent = `${quotaPct}%`;
    $('statQuotaNote').textContent = `of ${fmt(stats.quota_bytes)}`;

    // Dashboard node list
    renderDashNodes(nodes);
    renderDashNodeBars(nodes);
    renderDashRecentObjects(objects);

    // Objects tab
    renderObjects(objects);

    // Update upload object select for simulator/consistency
    updateObjectSelects(objects);

  } catch (e) {
    console.error('Refresh error:', e);
    toast(e.message, 'err');
  } finally {
    refreshBusy = false;
  }
}

// ─── Dashboard Renderers ────────────────────────────────────────────────────
function renderDashNodes(nodes) {
  $('dashNodeList').innerHTML = nodes.map(n => `
    <div class="dash-node-row">
      <span class="dash-dot ${n.status}"></span>
      <span class="dash-node-name">${esc(n.label)}</span>
      <span class="dash-node-detail">${n.objects} objects · ${fmt(n.used_bytes)}</span>
      <div class="dash-mini-bar"><div class="dash-mini-fill" style="width:${Math.min(100, n.utilization_pct)}%"></div></div>
    </div>
  `).join('');
}

function renderDashNodeBars(nodes) {
  const maxBytes = Math.max(...nodes.map(n => n.used_bytes), 1);
  $('dashNodeBars').innerHTML = nodes.map(n => `
    <div class="bar-chart-row">
      <div class="bar-chart-label">
        <span>${esc(n.label)}</span>
        <b>${fmt(n.used_bytes)}</b>
      </div>
      <div class="bar-chart-bg">
        <div class="bar-chart-fill" style="width:${Math.min(100, n.used_bytes / maxBytes * 100)}%"></div>
      </div>
    </div>
  `).join('');
}

function renderDashRecentObjects(objs) {
  const top = objs.slice(0, 5);
  $('dashRecentObjects').innerHTML = top.length
    ? top.map(o => objectRow(o, false)).join('')
    : '<div class="empty-state">No objects yet. Upload your first file.</div>';
}

// ─── Objects ─────────────────────────────────────────────────────────────────
function objectRow(o, full = true) {
  const s = o.healthy ? 'ok' : o.verified_replicas ? 'warn' : 'bad';
  const status = o.healthy ? 'VERIFIED' : o.verified_replicas ? 'DEGRADED' : 'UNAVAILABLE';
  const ext = (o.filename || '').split('.').pop().toUpperCase().slice(0, 4);
  return `<div class="object-row">
    <div class="file-icon">${esc(ext)}</div>
    <div class="obj-name">
      <b title="${esc(o.filename)}">${esc(o.filename)}</b>
      <small>${fmt(o.size)} · ${o.verified_replicas}/${o.replication} replicas · ${o.sha256?.slice(0,16)}…</small>
    </div>
    <span class="badge ${s}">${status}</span>
    <div class="row-actions">
      <button class="tiny" onclick="downloadObject('${o.object_id}')">↓ Download</button>
      ${full ? `<button class="tiny" onclick="showObjectDetail('${o.object_id}')">Detail</button>
      <button class="tiny" onclick="verifyObject('${o.object_id}')">Verify</button>
      <button class="tiny danger" onclick="deleteObject('${o.object_id}')">Delete</button>` : ''}
    </div>
  </div>`;
}

function renderObjects(objs) {
  const query = $('fileSearch')?.value?.toLowerCase() || '';
  const filterVal = $('objFilter')?.value || 'all';
  let filtered = objs.filter(o => o.filename.toLowerCase().includes(query));
  if (filterVal === 'ok') filtered = filtered.filter(o => o.healthy);
  else if (filterVal === 'warn') filtered = filtered.filter(o => !o.healthy && o.verified_replicas > 0);
  else if (filterVal === 'bad') filtered = filtered.filter(o => !o.verified_replicas);
  $('allObjects').innerHTML = filtered.length
    ? filtered.map(o => objectRow(o, true)).join('')
    : `<div class="empty-state">${query || filterVal !== 'all' ? 'No matching objects.' : 'Your vault is empty. Upload a file.'}</div>`;
}

function updateObjectSelects(objs) {
  const opts = '<option value="">— select object —</option>' + objs.map(o =>
    `<option value="${o.object_id}">${esc(o.filename)}</option>`).join('');
  ['simObjSelect', 'versionObjSelect'].forEach(id => {
    if ($(id)) $(id).innerHTML = opts;
  });
}

// ─── Node Manager ────────────────────────────────────────────────────────────
function renderNodeGrid(nodes) {
  $('nodeGrid').innerHTML = nodes.map(n => `
    <div class="node-card">
      <div class="node-card-head">
        <div>
          <h3>${esc(n.label)}</h3>
          <div class="node-id">${n.node}</div>
        </div>
        <span class="node-status-badge ${n.status}">● ${n.status.toUpperCase()}</span>
      </div>
      <div class="node-meter">
        <div class="node-meter-fill" style="width:${Math.min(100, n.utilization_pct)}%"></div>
      </div>
      <div class="node-meta-row"><span>Used</span><b>${fmt(n.used_bytes)}</b></div>
      <div class="node-meta-row"><span>Capacity</span><b>${fmt(n.capacity_bytes)}</b></div>
      <div class="node-meta-row"><span>Objects</span><b>${n.objects}</b></div>
      <div class="node-meta-row"><span>Utilization</span><b>${n.utilization_pct}%</b></div>
      <div class="node-heartbeat">💓 ${n.status === 'healthy' ? 'Heartbeat: ' + fmtTime(n.heartbeat) : 'Node Offline'}</div>
      <div class="node-actions">
        ${n.status === 'healthy'
          ? `<button class="btn-danger btn-sm" onclick="failNode('${n.node}')">Simulate Failure</button>
             <button class="btn-soft btn-sm" onclick="rebalance()">Rebalance</button>`
          : `<button class="btn-primary btn-sm" onclick="recoverNode('${n.node}')">Recover Node</button>`}
      </div>
    </div>
  `).join('');
}

// ─── Replication Map ─────────────────────────────────────────────────────────
async function loadReplicationMap() {
  try {
    const data = await api('/api/replication-map');
    if (!data.length) {
      $('repMapBody').innerHTML = '<div class="empty-state">No objects stored yet.</div>';
      return;
    }
    $('repMapBody').innerHTML = data.map(o => {
      const dots = ['node1','node2','node3','node4'].map(n => {
        const rd = o.replica_details.find(r => r.node === n);
        const ok = rd && rd.healthy;
        const exists = rd && rd.exists;
        const cls = ok ? 'ok' : exists ? 'fail' : 'none';
        const label = ok ? '✓' : exists ? '✗' : '·';
        return `<span class="replica-dot ${cls}" title="${rd?.label || n}: ${ok ? 'healthy' : exists ? 'corrupted/failed' : 'no replica'}">${label}</span>`;
      }).join('');
      const s = o.verified_replicas >= o.replication ? 'ok' : o.verified_replicas > 0 ? 'warn' : 'bad';
      return `<div class="repmap-row">
        <div><div class="repmap-obj">${esc(o.filename)}</div><div class="repmap-hash">${o.sha256?.slice(0,20)}…</div></div>
        ${dots}
        <span class="badge ${s}">${o.verified_replicas}/${o.replication}</span>
      </div>`;
    }).join('');
  } catch (e) {
    $('repMapBody').innerHTML = `<div class="empty-state">${esc(e.message)}</div>`;
  }
}

// ─── Failure Simulator ───────────────────────────────────────────────────────
function renderSimulator() {
  const nodes = nodeCache;
  const nodebtns = (action, msgId, icon, cls) => NODE_NAMES.map(n => {
    const nd = nodes.find(x => x.node === n);
    const status = nd?.status || 'healthy';
    if (action === 'fail' && status === 'failed') return '';
    if (action === 'recover' && status === 'healthy') return '';
    return `<button class="${cls} btn-sm" onclick="${action === 'fail' ? 'simKillNode' : action === 'recover' ? 'simRecoverNode' : 'simNetFail'}('${n}','${msgId}')">${icon} ${esc(nd?.label || n)}</button>`;
  }).join('');

  $('simNodeButtons').innerHTML = nodebtns('fail', 'simKillMsg', '💀', 'btn-danger') || '<div class="empty-state" style="padding:8px">No healthy nodes to fail.</div>';
  $('simNetButtons').innerHTML = NODE_NAMES.map(n => {
    const nd = nodes.find(x => x.node === n);
    return `<button class="btn-soft btn-sm" onclick="simNetFail('${n}','simNetMsg')">🌐 ${esc(nd?.label || n)}</button>`;
  }).join('');
  $('simRecoverButtons').innerHTML = nodebtns('recover', 'simRecoverMsg', '♻', 'btn-primary') || '<div class="empty-state" style="padding:8px">All nodes healthy — nothing to recover.</div>';
  renderSimLiveStatus(nodes);
}

const NODE_NAMES = ['node1','node2','node3','node4'];
const NODE_LABELS = { node1:'Storage Node 01', node2:'Storage Node 02', node3:'Storage Node 03', node4:'Storage Node 04' };

function renderSimLiveStatus(nodes) {
  $('simLiveStatus').innerHTML = nodes.map(n => `
    <div class="sim-status-row">
      <span class="sim-dot ${n.status}"></span>
      <span class="sim-node-name">${esc(n.label)}</span>
      <span class="sim-node-detail">${n.status.toUpperCase()} · ${n.objects} objects · ${fmt(n.used_bytes)}</span>
    </div>
  `).join('');
}

function showSimMsg(elId, msg, type = '') {
  const el = $(elId);
  el.textContent = msg;
  el.className = `sim-msg show${type ? ' ' + type : ''}`;
}

async function simKillNode(node, msgId) {
  showSimMsg(msgId, 'Simulating failure…');
  try {
    const d = await api(`/api/nodes/${node}/fail`, { method: 'POST' });
    showSimMsg(msgId, `${NODE_LABELS[node]} marked as FAILED. Repaired ${d.repaired.length} replica(s).`, 'err');
    await refreshAll();
    renderSimulator();
  } catch (e) { showSimMsg(msgId, e.message, 'err'); }
}

async function simRecoverNode(node, msgId) {
  showSimMsg(msgId, 'Recovering node…');
  try {
    const d = await api(`/api/nodes/${node}/recover`, { method: 'POST' });
    showSimMsg(msgId, `${NODE_LABELS[node]} recovered. Restored ${d.repaired.length} replica(s).`, 'ok');
    await refreshAll();
    renderSimulator();
  } catch (e) { showSimMsg(msgId, e.message, 'err'); }
}

async function simNetFail(node, msgId) {
  showSimMsg(msgId, 'Cutting network…');
  try {
    const d = await api(`/api/simulate/network-failure/${node}`, { method: 'POST' });
    showSimMsg(msgId, `Network failure on ${NODE_LABELS[node]}. Node is now unreachable.`, 'err');
    await refreshAll();
    renderSimulator();
  } catch (e) { showSimMsg(msgId, e.message, 'err'); }
}

async function runCorrupt() {
  const oid = $('simObjSelect').value;
  const node = $('simNodeSelect').value;
  if (!oid || !node) { showSimMsg('simCorruptMsg', 'Select an object and a node first.', 'err'); return; }
  showSimMsg('simCorruptMsg', 'Corrupting replica…');
  try {
    const d = await api(`/api/corrupt/${oid}/${node}`, { method: 'POST' });
    showSimMsg('simCorruptMsg', `Byte flipped on ${node}. SHA-256 now mismatches. Auto-repair restored ${d.repaired.length} replica(s).`, 'err');
    await refreshAll();
  } catch (e) { showSimMsg('simCorruptMsg', e.message, 'err'); }
}

// ─── Auto Repair ─────────────────────────────────────────────────────────────
async function runRepair() {
  animatePipeline();
  try {
    const d = await api('/api/repair', { method: 'POST' });
    const el = $('repairResults');
    if (!d.repaired.length) {
      el.innerHTML = `<div class="empty-state" style="color:var(--green)">✓ All replicas healthy — nothing to repair. (${fmtMs(d.duration_ms)})</div>`;
    } else {
      el.innerHTML = d.repaired.map(r => `
        <div class="repair-result-item">
          <span class="repair-obj-name">${esc(r.filename)}</span>
          <span class="repair-node-badge">Copied to ${esc(NODE_LABELS[r.node] || r.node)}</span>
        </div>
      `).join('');
    }
    toast(`Repair complete: ${d.repaired.length} replica(s) restored`, 'ok');
    await refreshAll();
    renderRepairStatus();
  } catch (e) {
    $('repairResults').innerHTML = `<div class="empty-state" style="color:var(--red)">${esc(e.message)}</div>`;
  }
}

function animatePipeline() {
  const steps = ['pipeDetect','pipeCopy','pipeVerify','pipeRecover'];
  steps.forEach(s => $(s).className = 'pipe-step');
  steps.forEach((s, i) => {
    setTimeout(() => {
      steps.forEach(x => $(x).className = 'pipe-step');
      $(s).className = 'pipe-step active';
    }, i * 600);
    setTimeout(() => {
      $(s).className = 'pipe-step done';
    }, (i + 1) * 600);
  });
}

function renderRepairStatus() {
  const nodes = nodeCache;
  const el = $('repairObjectStatus');
  if (!objectCache.length) {
    el.innerHTML = '<div class="empty-state">No objects to display.</div>';
    return;
  }
  el.innerHTML = objectCache.map(o => {
    const s = o.healthy ? 'ok' : o.verified_replicas ? 'warn' : 'bad';
    return `<div class="object-row">
      <div class="file-icon">${esc((o.filename || '').split('.').pop().toUpperCase().slice(0, 4))}</div>
      <div class="obj-name">
        <b>${esc(o.filename)}</b>
        <small>${o.verified_replicas}/${o.replication} replicas verified · ${o.replicas?.filter(r => r.status === 'corrupted').length || 0} corrupted</small>
      </div>
      <span class="badge ${s}">${o.healthy ? 'HEALTHY' : o.verified_replicas ? 'DEGRADED' : 'FAILED'}</span>
    </div>`;
  }).join('');
}

// ─── Integrity ───────────────────────────────────────────────────────────────
async function runIntegrity() {
  const btn = $('integrityBtn');
  btn.textContent = '⏳ Scanning…';
  btn.disabled = true;
  const el = $('integrityResults');
  el.innerHTML = '<div class="empty-state">Running SHA-256 scan on all replicas…</div>';
  try {
    const results = await api('/api/integrity');
    if (!results.length) {
      el.innerHTML = '<div class="empty-state">No objects to check.</div>';
      return;
    }
    el.innerHTML = results.map(obj => {
      const allOk = obj.all_ok;
      const cls = allOk ? 'ok' : 'bad';
      return `<div class="integrity-row">
        <div class="integrity-head" onclick="this.nextElementSibling.classList.toggle('hidden')">
          <div>
            <div class="integrity-filename">${esc(obj.filename)}</div>
            <div class="integrity-sha">Expected: ${obj.expected_sha256}</div>
          </div>
          <span class="badge ${cls}">${allOk ? '✓ CLEAN' : '✗ CORRUPTED'}</span>
        </div>
        <div class="integrity-body hidden">
          ${obj.nodes.map(n => `
            <div class="integrity-node-row">
              <span class="dash-dot ${n.exists && n.match ? 'healthy' : 'failed'}" style="flex-shrink:0;width:8px;height:8px;border-radius:50%;background:${n.exists && n.match ? 'var(--green)' : n.exists ? 'var(--red)' : 'var(--text3)'}"></span>
              <span style="flex:1;font-weight:600;font-size:12px">${NODE_LABELS[n.node] || n.node}</span>
              ${n.exists
                ? `<span class="integrity-check ${n.match ? 'ok' : 'fail'}">${n.checksum?.slice(0,20)}… ${n.match ? '✓ MATCH' : '✗ MISMATCH'}</span>`
                : `<span class="integrity-check none">No replica</span>`}
            </div>
          `).join('')}
        </div>
      </div>`;
    }).join('');
    toast(`Integrity scan complete: ${results.filter(r => r.all_ok).length}/${results.length} clean`, allOk ? 'ok' : '');
  } catch (e) {
    el.innerHTML = `<div class="empty-state" style="color:var(--red)">${esc(e.message)}</div>`;
  } finally {
    btn.textContent = '🔒 Run Full Scan';
    btn.disabled = false;
  }
}

// ─── Rebalancer ──────────────────────────────────────────────────────────────
function renderRebalancerBars() {
  const nodes = nodeCache;
  const maxBytes = Math.max(...nodes.map(n => n.used_bytes), 1);
  $('rebalanceBars').innerHTML = nodes.map(n => `
    <div class="rebalance-bar-row">
      <div class="rebalance-bar-label">
        <span>${esc(n.label)} <small style="color:var(--text3)">(${n.status})</small></span>
        <b>${fmt(n.used_bytes)} / ${fmt(n.capacity_bytes)} · ${n.utilization_pct}%</b>
      </div>
      <div class="rebalance-bar-bg">
        <div class="rebalance-bar-fill" style="width:${Math.min(100, n.used_bytes / maxBytes * 100)}%"></div>
      </div>
    </div>
  `).join('');
}

async function runRebalance() {
  const el = $('rebalanceLog');
  el.innerHTML = '<div class="empty-state">Rebalancing…</div>';
  try {
    const d = await api('/api/rebalance', { method: 'POST' });
    if (!d.details.length) {
      el.innerHTML = `<div class="empty-state" style="color:var(--green)">✓ Distribution already balanced — no moves needed.</div>`;
    } else {
      el.innerHTML = d.details.map(m => `
        <div class="rebalance-move-row">
          <span class="move-file">${esc(m.filename)}</span>
          <span class="move-from">${NODE_LABELS[m.from] || m.from}</span>
          <span class="move-arrow">→</span>
          <span class="move-to">${NODE_LABELS[m.to] || m.to}</span>
          <span style="font-size:11px;color:var(--text3)">${fmt(m.bytes)}</span>
        </div>
      `).join('');
    }
    toast(`Rebalanced: ${d.moved} replica(s) moved`, 'ok');
    await refreshAll();
    renderRebalancerBars();
  } catch (e) {
    el.innerHTML = `<div class="empty-state" style="color:var(--red)">${esc(e.message)}</div>`;
  }
}

// ─── Consistency ──────────────────────────────────────────────────────────────
async function loadConsistency() {
  try {
    const policy = await api('/api/policies');
    $('consistencyQuorum').innerHTML = `
      <div class="consist-quorum-item"><span>Replication Factor</span><span class="consist-quorum-val">${policy.replication_factor}</span></div>
      <div class="consist-quorum-item"><span>Read Quorum</span><span class="consist-quorum-val">${policy.read_quorum} node(s)</span></div>
      <div class="consist-quorum-item"><span>Write Quorum</span><span class="consist-quorum-val">${policy.write_quorum} node(s)</span></div>
      <div class="consist-quorum-item"><span>Auto Repair</span><span class="consist-quorum-val">${policy.auto_repair ? 'Enabled' : 'Disabled'}</span></div>
      <div class="consist-quorum-item"><span>Versioning</span><span class="consist-quorum-val">${policy.versioning ? 'Enabled' : 'Disabled'}</span></div>
    `;
    // Write locks — no direct API to list, show message
    $('consistencyLocks').innerHTML = '<div class="empty-state">No active write locks detected.</div>';
  } catch (e) {
    $('consistencyQuorum').innerHTML = `<div class="empty-state">${esc(e.message)}</div>`;
  }
}

async function loadVersionInfo() {
  const oid = $('versionObjSelect').value;
  if (!oid) { $('versionInfo').innerHTML = '<div class="empty-state">Select an object above.</div>'; return; }
  try {
    const v = await api(`/api/versions/${oid}`);
    $('versionInfo').innerHTML = `
      <div class="consist-quorum-item"><span>Filename</span><b>${esc(v.filename)}</b></div>
      <div class="consist-quorum-item"><span>Current Version</span><b>v${v.current_version}</b></div>
      <div class="consist-quorum-item"><span>Versioning Enabled</span><b>${v.versioning_enabled ? 'Yes' : 'No — enable in Policies'}</b></div>
      <div class="consist-quorum-item"><span>Note</span><b style="color:var(--text3);font-size:11px">${esc(v.note)}</b></div>
    `;
  } catch (e) {
    $('versionInfo').innerHTML = `<div class="empty-state" style="color:var(--red)">${esc(e.message)}</div>`;
  }
}

// ─── Policies ─────────────────────────────────────────────────────────────────
async function loadPolicies() {
  try {
    const p = await api('/api/policies');
    $('polRepFactor').value = p.replication_factor;
    $('polRepFactorVal').textContent = p.replication_factor;
    $('polReadQ').value = p.read_quorum;
    $('polReadQVal').textContent = p.read_quorum;
    $('polWriteQ').value = p.write_quorum;
    $('polWriteQVal').textContent = p.write_quorum;
    $('polMaxUpload').value = Math.round(p.max_upload_bytes / 1048576);
    $('polMaxUploadVal').textContent = Math.round(p.max_upload_bytes / 1048576) + ' MB';
    $('polQuota').value = Math.round(p.quota_bytes / 1073741824);
    $('polQuotaVal').textContent = Math.round(p.quota_bytes / 1073741824) + ' GB';
    $('polAutoRepair').checked = !!p.auto_repair;
    $('polAutoRepairLbl').textContent = p.auto_repair ? 'Enabled' : 'Disabled';
    $('polVersioning').checked = !!p.versioning;
    $('polVersioningLbl').textContent = p.versioning ? 'Enabled' : 'Disabled';
  } catch (e) {
    toast(e.message, 'err');
  }
}

function updatePolLabel(inputId, labelId, suffix = '') {
  const val = $(inputId).value;
  $(labelId).textContent = val + (suffix ? ' ' + suffix : '');
  if (inputId === 'polAutoRepair') $('polAutoRepairLbl').textContent = $(inputId).checked ? 'Enabled' : 'Disabled';
  if (inputId === 'polVersioning') $('polVersioningLbl').textContent = $(inputId).checked ? 'Enabled' : 'Disabled';
}

// Toggle label updates
$('polAutoRepair').addEventListener('change', () => {
  $('polAutoRepairLbl').textContent = $('polAutoRepair').checked ? 'Enabled' : 'Disabled';
});
$('polVersioning').addEventListener('change', () => {
  $('polVersioningLbl').textContent = $('polVersioning').checked ? 'Enabled' : 'Disabled';
});

async function savePolicies() {
  const msg = $('policyMsg');
  msg.textContent = 'Saving…'; msg.className = 'policy-msg';
  try {
    await api('/api/policies', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        replication_factor: parseInt($('polRepFactor').value),
        read_quorum: parseInt($('polReadQ').value),
        write_quorum: parseInt($('polWriteQ').value),
        max_upload_bytes: parseInt($('polMaxUpload').value) * 1048576,
        quota_bytes: parseInt($('polQuota').value) * 1073741824,
        auto_repair: $('polAutoRepair').checked ? 1 : 0,
        versioning: $('polVersioning').checked ? 1 : 0,
      })
    });
    msg.textContent = '✓ Policies saved successfully.';
    msg.className = 'policy-msg ok';
    toast('Policies updated', 'ok');
  } catch (e) {
    msg.textContent = e.message;
    msg.className = 'policy-msg err';
  }
}

// ─── Monitoring ────────────────────────────────────────────────────────────────
async function loadMonitoring() {
  try {
    const m = await api('/api/monitoring');
    $('monAvgLat').textContent = fmtMs(m.avg_latency_ms);
    $('monP99Lat').textContent = fmtMs(m.p99_latency_ms);
    $('monThroughput').textContent = fmtBps(m.throughput_bps);
    $('monRepairs').textContent = m.repairs_last_hour;
    $('monFailures').textContent = m.failures_last_hour;
    $('monOps').textContent = m.operations_last_5m;
    $('monEventLog').innerHTML = m.events.length
      ? m.events.map(e => eventRow(e)).join('')
      : '<div class="empty-state">No events yet.</div>';
  } catch (e) {
    toast(e.message, 'err');
  }
}

function eventRow(e) {
  const sev = e.severity || 'info';
  return `<div class="event-row">
    <div class="event-dot-box"><div class="event-dot ${sev}"></div></div>
    <div style="flex:1">
      <div class="event-type ${sev}">${esc(e.event_type)}</div>
      <div class="event-msg">${esc(e.message)}</div>
      <div class="event-time">${fmtTime(e.created_at)}</div>
    </div>
  </div>`;
}

// ─── Admin ─────────────────────────────────────────────────────────────────────
async function loadAdminData() {
  try {
    const [stats, users, events] = await Promise.all([
      api('/api/admin/stats'),
      api('/api/admin/users'),
      api('/api/admin/events')
    ]);
    $('admUsers').textContent = stats.total_users;
    $('admObjects').textContent = stats.total_objects;
    $('admBytes').textContent = fmt(stats.total_bytes);
    $('admEvents').textContent = stats.events_today;

    $('adminUserTable').innerHTML = [
      `<div class="admin-user-row head">
        <span>Email</span><span>Role</span><span>Objects</span><span>Storage</span><span>Actions</span>
      </div>`
    ].concat(users.map(u => `
      <div class="admin-user-row">
        <span class="admin-email" title="${esc(u.email)}">${esc(u.email)} ${u.is_suspended ? '<span class="suspended-badge">Suspended</span>' : ''}</span>
        <span class="user-role-badge ${u.role}">${esc(u.role)}</span>
        <span>${u.obj_count}</span>
        <span>${fmt(u.total_bytes)}</span>
        <div class="admin-actions">
          ${!u.is_suspended
            ? `<button class="btn-danger btn-sm" onclick="adminSuspend('${u.user_id}',true)">Suspend</button>`
            : `<button class="btn-soft btn-sm" onclick="adminSuspend('${u.user_id}',false)">Unsuspend</button>`}
          <button class="btn-soft btn-sm" onclick="viewUserObjects('${u.user_id}','${esc(u.email)}')">Objects</button>
        </div>
      </div>
    `)).join('');

    $('adminEventLog').innerHTML = events.slice(0, 50).map(e => eventRow({ ...e, message: (e.email ? `[${e.email}] ` : '') + e.message })).join('');
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function adminSuspend(uid, suspend) {
  try {
    await api(`/api/admin/users/${uid}/suspend`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ suspended: suspend })
    });
    toast(`User ${suspend ? 'suspended' : 'unsuspended'}`, 'ok');
    loadAdminData();
  } catch (e) { toast(e.message, 'err'); }
}

async function viewUserObjects(uid, email) {
  toast(`Loading objects for ${email}…`);
  try {
    const objs = await api(`/api/admin/users/${uid}/objects`);
    const html = objs.length
      ? objs.map(o => `<div style="padding:8px 0;border-bottom:1px solid var(--border);font-size:12px">
          <b>${esc(o.filename)}</b> · ${fmt(o.size)} · ${o.verified_replicas}/${o.replication} replicas
        </div>`).join('')
      : '<div class="empty-state">No objects.</div>';
    $('objectModalContent').innerHTML = `<h2>${esc(email)}'s Objects</h2><div style="margin-top:16px">${html}</div>`;
    $('objectModal').classList.remove('hidden');
  } catch (e) { toast(e.message, 'err'); }
}

// ─── Super Admin ────────────────────────────────────────────────────────────────
async function loadSuperAdminData() {
  try {
    const [stats, users] = await Promise.all([
      api('/api/admin/stats'),
      api('/api/admin/users')
    ]);

    // Node usage
    const maxBytes = Math.max(...Object.values(stats.node_usage), 1);
    $('saNodeUsage').innerHTML = Object.entries(stats.node_usage).map(([node, bytes]) => `
      <div class="rebalance-bar-row">
        <div class="rebalance-bar-label">
          <span>${NODE_LABELS[node] || node}</span>
          <b>${fmt(bytes)}</b>
        </div>
        <div class="rebalance-bar-bg">
          <div class="rebalance-bar-fill" style="width:${Math.min(100, bytes / maxBytes * 100)}%"></div>
        </div>
      </div>
    `).join('');

    // Full user table with role control + delete
    $('saUserTable').innerHTML = [
      `<div class="admin-user-row head">
        <span>Email</span><span>Role</span><span>Objects</span><span>Storage</span><span>Actions</span>
      </div>`
    ].concat(users.map(u => `
      <div class="admin-user-row">
        <span class="admin-email">${esc(u.email)} ${u.is_suspended ? '<span class="suspended-badge">Suspended</span>' : ''}</span>
        <select class="filter-select" style="font-size:11px;padding:4px 8px" onchange="saSetRole('${u.user_id}',this.value)">
          <option value="user" ${u.role==='user'?'selected':''}>User</option>
          <option value="admin" ${u.role==='admin'?'selected':''}>Admin</option>
          <option value="superadmin" ${u.role==='superadmin'?'selected':''}>SuperAdmin</option>
        </select>
        <span>${u.obj_count}</span>
        <span>${fmt(u.total_bytes)}</span>
        <div class="admin-actions">
          ${!u.is_suspended
            ? `<button class="btn-danger btn-sm" onclick="adminSuspend('${u.user_id}',true)">Suspend</button>`
            : `<button class="btn-soft btn-sm" onclick="adminSuspend('${u.user_id}',false)">Unsuspend</button>`}
          <button class="btn-danger btn-sm" onclick="saDeleteUser('${u.user_id}','${esc(u.email)}')">Delete</button>
        </div>
      </div>
    `)).join('');
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function saSetRole(uid, role) {
  try {
    await api(`/api/admin/users/${uid}/role`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role })
    });
    toast(`Role updated to ${role}`, 'ok');
  } catch (e) { toast(e.message, 'err'); loadSuperAdminData(); }
}

async function saDeleteUser(uid, email) {
  if (!confirm(`PERMANENTLY DELETE account "${email}" and ALL their data? This cannot be undone.`)) return;
  try {
    await api(`/api/admin/users/${uid}`, { method: 'DELETE' });
    toast(`Deleted account: ${email}`, 'ok');
    loadSuperAdminData();
  } catch (e) { toast(e.message, 'err'); }
}

// ─── Upload ─────────────────────────────────────────────────────────────────
function openUpload() {
  lastUploadFocus = document.activeElement;
  $('uploadModal').classList.remove('hidden');
  $('dropZone').focus();
}
function closeUpload() {
  if (uploadBusy) return;
  $('uploadModal').classList.add('hidden');
  $('uploadMessage').textContent = '';
  lastUploadFocus?.focus();
}
function closeObjectModal() {
  $('objectModal').classList.add('hidden');
}

$('fileInput').onchange = () => {
  const f = $('fileInput').files[0];
  if (f) {
    $('dropTitle').textContent = f.name;
    $('dropHint').textContent = fmt(f.size) + ' · Ready to upload';
  }
};
$('dropZone').ondragover = e => { e.preventDefault(); $('dropZone').style.borderColor = 'var(--blue)'; };
$('dropZone').ondragleave = () => { $('dropZone').style.borderColor = ''; };
$('dropZone').ondrop = e => {
  e.preventDefault();
  $('dropZone').style.borderColor = '';
  $('fileInput').files = e.dataTransfer.files;
  $('fileInput').dispatchEvent(new Event('change'));
};

async function uploadFile() {
  if (uploadBusy) return;
  const f = $('fileInput').files[0];
  if (!f) { $('uploadMessage').textContent = 'Choose a file first.'; return; }
  const fd = new FormData();
  fd.append('file', f);
  uploadBusy = true;
  $('uploadButton').disabled = true;
  $('uploadProgress').classList.remove('hidden');
  $('uploadProgress').value = 0;
  const msgEl = $('uploadMessage');
  msgEl.textContent = 'Uploading and replicating…';
  msgEl.className = 'upload-msg';
  try {
    const d = await new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', `/api/upload?replication=${$('replication').value}`);
      xhr.timeout = 300000;
      xhr.upload.onprogress = e => { if (e.lengthComputable) $('uploadProgress').value = e.loaded / e.total * 100; };
      xhr.onload = () => {
        let data;
        try { data = JSON.parse(xhr.responseText); } catch { reject(new Error('Unexpected server response')); return; }
        if (xhr.status >= 200 && xhr.status < 300) resolve(data);
        else reject(new Error(typeof data.detail === 'string' ? data.detail : `Upload failed (${xhr.status})`));
      };
      xhr.onerror = () => reject(new Error('Connection lost.'));
      xhr.ontimeout = () => reject(new Error('Upload timed out.'));
      xhr.send(fd);
    });
    msgEl.textContent = `✓ ${d.filename} saved to ${d.nodes.length} nodes. SHA-256: ${d.sha256.slice(0, 20)}…`;
    msgEl.className = 'upload-msg ok';
    toast(`${d.filename} uploaded & replicated`, 'ok');
    $('fileInput').value = '';
    $('dropTitle').textContent = 'Choose another file';
    $('dropHint').textContent = 'Up to 100 MB · SHA-256 verified';
    await refreshAll();
  } catch (e) {
    msgEl.textContent = e.message;
    msgEl.className = 'upload-msg err';
  } finally {
    uploadBusy = false;
    $('uploadButton').disabled = false;
    $('uploadProgress').classList.add('hidden');
  }
}

// ─── Object Actions ─────────────────────────────────────────────────────────
async function downloadObject(id) {
  try {
    const r = await fetch('/api/download/' + id, { credentials: 'same-origin' });
    if (!r.ok) { const d = await r.json(); throw new Error(d.detail || 'Download failed'); }
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = objectCache.find(o => o.object_id === id)?.filename || 'download';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  } catch (e) { toast(e.message, 'err'); }
}

async function verifyObject(id) {
  try {
    const d = await api('/api/objects/' + id);
    toast(`${d.verified_replicas}/${d.replication} replicas verified. ${d.integrity ? '✓ Integrity confirmed.' : '✗ No valid copy.'}`);
    await refreshAll();
  } catch (e) { toast(e.message, 'err'); }
}

async function deleteObject(id) {
  const o = objectCache.find(o => o.object_id === id);
  if (!o || !confirm(`Permanently delete "${o.filename}" and all its replicas?`)) return;
  try {
    await api('/api/objects/' + id, { method: 'DELETE' });
    toast('Object deleted', 'ok');
    await refreshAll();
  } catch (e) { toast(e.message, 'err'); }
}

async function showObjectDetail(id) {
  try {
    const o = await api('/api/objects/' + id);
    const tags = o.tags || {};
    const tagStr = Object.entries(tags).map(([k, v]) => `${k}: ${v}`).join('\n') || 'No tags';
    $('objectModalContent').innerHTML = `
      <div class="section-eyebrow">OBJECT DETAIL</div>
      <h2>${esc(o.filename)}</h2>
      <div style="margin:16px 0">
        <div class="consist-quorum-item"><span>Object ID</span><code>${esc(o.object_id)}</code></div>
        <div class="consist-quorum-item"><span>Size</span><b>${fmt(o.size)}</b></div>
        <div class="consist-quorum-item"><span>SHA-256</span><code style="font-size:10px">${esc(o.sha256)}</code></div>
        <div class="consist-quorum-item"><span>Replication</span><b>${o.verified_replicas}/${o.replication}</b></div>
        <div class="consist-quorum-item"><span>Version</span><b>v${o.version}</b></div>
        <div class="consist-quorum-item"><span>Created</span><b>${fmtTime(o.created_at)}</b></div>
        <div class="consist-quorum-item"><span>Tags</span><pre style="font-size:11px;color:var(--text2)">${esc(tagStr)}</pre></div>
      </div>
      <div class="card-head"><h2>Replica Status</h2></div>
      ${(o.replicas || []).map(r => `
        <div class="sim-status-row">
          <span class="sim-dot ${r.status === 'healthy' ? 'healthy' : 'failed'}"></span>
          <span style="flex:1;font-weight:700;font-size:13px">${NODE_LABELS[r.node] || r.node}</span>
          <span class="badge ${r.status === 'healthy' ? 'ok' : 'bad'}">${r.status.toUpperCase()}</span>
          <span style="font-size:11px;color:var(--text3)">${r.exists ? fmt(r.size) : 'No file'}</span>
        </div>`).join('')}
      <div style="display:flex;gap:8px;margin-top:20px">
        <button class="btn-primary" onclick="downloadObject('${o.object_id}');closeObjectModal()">↓ Download</button>
        <button class="btn-soft" onclick="verifyObject('${o.object_id}')">Verify</button>
        <button class="btn-danger" onclick="deleteObject('${o.object_id}');closeObjectModal()">Delete</button>
      </div>
    `;
    $('objectModal').classList.remove('hidden');
  } catch (e) { toast(e.message, 'err'); }
}

// ─── Node Quick Actions ──────────────────────────────────────────────────────
async function failNode(node) {
  try {
    const d = await api(`/api/nodes/${node}/fail`, { method: 'POST' });
    toast(`${NODE_LABELS[node]} failure simulated. ${d.repaired.length} replica(s) repaired.`);
    await refreshAll();
    renderNodeGrid(nodeCache);
  } catch (e) { toast(e.message, 'err'); }
}

async function recoverNode(node) {
  try {
    const d = await api(`/api/nodes/${node}/recover`, { method: 'POST' });
    toast(`${NODE_LABELS[node]} recovered. ${d.repaired.length} replica(s) restored.`, 'ok');
    await refreshAll();
    renderNodeGrid(nodeCache);
  } catch (e) { toast(e.message, 'err'); }
}

async function repairAll() {
  try {
    const d = await api('/api/repair', { method: 'POST' });
    toast(`Repair complete: ${d.repaired.length} replica(s) restored`, 'ok');
    await refreshAll();
  } catch (e) { toast(e.message, 'err'); }
}

async function rebalance() {
  try {
    const d = await api('/api/rebalance', { method: 'POST' });
    toast(`Rebalanced: ${d.moved} replica(s) moved`, 'ok');
    await refreshAll();
  } catch (e) { toast(e.message, 'err'); }
}

async function resetVault() {
  if (!confirm('Permanently delete ALL objects in your vault? This cannot be undone.')) return;
  try {
    await api('/api/reset', { method: 'DELETE' });
    toast('Vault cleared', 'ok');
    await refreshAll();
  } catch (e) { toast(e.message, 'err'); }
}

// ─── Keyboard & Accessibility ────────────────────────────────────────────────
$('uploadModal').addEventListener('keydown', e => {
  if (e.key === 'Escape') closeUpload();
});
$('objectModal').addEventListener('keydown', e => {
  if (e.key === 'Escape') closeObjectModal();
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    closeUpload();
    closeObjectModal();
  }
});

// Click backdrop to close modals
$('uploadModal').addEventListener('click', e => { if (e.target === $('uploadModal')) closeUpload(); });
$('objectModal').addEventListener('click', e => { if (e.target === $('objectModal')) closeObjectModal(); });

// ─── Node grid subscription ──────────────────────────────────────────────────
// Patch refreshAll to also update node grid when nodes tab is visible
const _origRefresh = refreshAll;
window.addEventListener('DOMContentLoaded', () => {
  // After initial render, hook into node grid
});

// Override to also render node grid
const _baseRefreshAll = async function() {
  if (refreshBusy || $('appShell').classList.contains('hidden')) return;
  refreshBusy = true;
  try {
    const [stats, nodes, objects, health] = await Promise.all([
      api('/api/stats'), api('/api/nodes'), api('/api/objects'), api('/api/health')
    ]);
    nodeCache = nodes;
    objectCache = objects;

    const dot = $('healthDot');
    const txt = $('healthText');
    if (health.healthy === health.total) {
      dot.className = 'health-dot'; txt.textContent = 'All Nodes Online';
    } else if (health.healthy > 0) {
      dot.className = 'health-dot warn'; txt.textContent = `${health.healthy}/${health.total} Nodes`;
    } else {
      dot.className = 'health-dot err'; txt.textContent = 'All Nodes Down';
    }

    $('statObjects').textContent = stats.objects;
    $('statObjectsNote').textContent = fmt(stats.logical_bytes) + ' logical';
    $('statPhysical').textContent = fmt(stats.physical_bytes);
    $('statNodes').textContent = `${health.healthy}/${health.total}`;
    const quotaPct = Math.round(stats.quota_used / stats.quota_bytes * 100);
    $('statQuota').textContent = `${quotaPct}%`;
    $('statQuotaNote').textContent = `of ${fmt(stats.quota_bytes)}`;

    renderDashNodes(nodes);
    renderDashNodeBars(nodes);
    renderDashRecentObjects(objects);
    renderObjects(objects);
    renderNodeGrid(nodes);
    updateObjectSelects(objects);
  } catch (e) {
    console.error(e);
    toast(e.message, 'err');
  } finally {
    refreshBusy = false;
  }
};

// Replace refreshAll
window.refreshAll = _baseRefreshAll;

// ─── Init ────────────────────────────────────────────────────────────────────
checkAuth();
setInterval(() => { if (!document.hidden) window.refreshAll(); }, 30000);
